﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphDataStructure
{

    public class Graph<T>
    {

        public enum GraphDirection
        {
            None,
            Directed,
            NotDirected
        }
        public enum GraphConnection
        {
            Unknown,
            Disconnected,
            Connected, // for undirected graphs: there exists a path between each pair of distinct vertices
            WeaklyConnected, // graph if the undirected underline graph is connected
            StronglyConnected // graph there exists a directed path between each pair of distinct vertices
        }
        public enum LayoutType
        {
            None,
            BinaryMatrix,
            WeightedMatrix,
            List
        }
        // properties

        public int MaxEdges
        {
            get
            {
                int nCount = this.Nodes.Count;
                return IsDirected ? this.MaxEdgesDirected : this.MaxEdgesUndirected;
            }
            set { }
        }
        public int MaxEdgesDirected
        {
            get
            {
                int nCount = this.Nodes.Count;
                return nCount * (nCount - 1);
            }
            set { }
        }
        public int MaxEdgesUndirected
        {
            get
            {
                int nCount = this.Nodes.Count;
               return nCount * (nCount - 1) / 2;
            }
            set { }
        }

        public bool IsDirected 
        {
            get
            {
                bool result = false;
                switch (this.ForceDirection)
                {
                    case GraphDirection.None:
                        result = HasDirectEdges;
                        break;
                    case GraphDirection.Directed:
                        result = true;
                        break;
                    case GraphDirection.NotDirected:
                        result = false;
                        break;
                }
                return result;
            }
            set { }
        
        } // false if all edges are underected
        public GraphDirection ForceDirection { get; set; }
        public bool HasDirectEdges 
        { 
            get { return this.Edges.Where(x => x.IsDirected == true).ToList().Count > 0 ? true : false;}
            set { }
        }

        public bool IsSimple
        {
            get
            {
                bool result = false;
                if (!IsWeighted && !IsDirected && !IsSelfLoop && !IsMultiEdge)
                {
                    result = true;
                }
                return result;
            }
            set { }
        }

        public GraphConnection Connection
        {
            get
            {
                GraphConnection connection = GraphConnection.Unknown;
                if (!IsMultiEdge&&!IsSelfLoop)
                {
                    if (!this.HasDirectEdges && this.Edges.Count == this.MaxEdgesDirected)
                    {
                        connection = GraphConnection.Connected;
                    }
                    if (this.HasDirectEdges && this.Edges.Count == this.MaxEdgesUndirected)
                    {
                        connection = GraphConnection.StronglyConnected;
                    }
                    if (this.HasDirectEdges && this.Edges.Count == this.MaxEdgesUndirected)
                    {
                        connection = GraphConnection.WeaklyConnected;
                    }
                }
                return connection;
            }
            set { }
        }//
        public bool AllowDisconnected { get; set; }

        public bool IsSelfLoop { get{return false;} set { } } // has edges starting and ending at same vertex
        public bool AllowSelfLoop { get; set; }

        public bool IsComplete { get{return false;} set { } } // all vertices are adjacent
        public bool AllowIncomplete { get; set; }

        public bool IsWeighted { get; set; } // edges have weight
        public bool IsPlanar { get { return false; } set { } } // no edge cross other
        public bool AllowNotPanar { get; set; }

        public bool IsMultiEdge { get { return false; } set { } } // there are more than one edge between two vertices
        public bool AllowMultiEdge { get; set; }

        public bool IsCyclic { get{return false;} set { } } // if there is a Cyclic Path
        public bool IsDense {
            get
            {
                int nCount = this.Nodes.Count;

                Decimal midpoint = (nCount - 1 + (this.MaxEdges - (nCount - 1)));
                return this.Edges.Count > midpoint ? true : false; 
            }
            set { }
        } // true if there are more edges than vertices, best for matrix

        public LayoutType ForcedLayout { get; set; }
        public LayoutType Layout
        {
            get
            {
                LayoutType layout = LayoutType.None;
                if (this.ForcedLayout == LayoutType.None)
                {
                    if (this.IsDense)
                    {
                        if (this.IsWeighted)
                        {
                            layout = LayoutType.WeightedMatrix;
                        }
                        else
                        {
                            layout = LayoutType.BinaryMatrix;
                        }
                    }
                    else
                    {
                        layout = LayoutType.List;
                    }
                }
                else
                {
                    layout = ForcedLayout;
                }
                return layout;
            }
            set { }
        } // determines which ajancency to use: matrix or list. 

        public List<Vertex<T>> Nodes { get; set; } // Matrix
        public List<Edge<T>> Edges { get; set; }

        //public Dictionary<Vertex<T>,bool[]> BinaryMatrix { get; set; }
        //public Dictionary<Vertex<T>, decimal[]> WeightedMatrix { get; set; }
        //public List<LinkedList<Vertex<T>>> List { get; set; } // List

        public GraphLayout<T> GraphLayout { get; set; }

        // constructors
        public Graph()
        {
            this.ForcedLayout = LayoutType.None;
            this.ForceDirection = GraphDirection.None;
            //this.Connection = GraphConnection.Disconnected;
            this.AllowDisconnected = true;
            this.AllowSelfLoop = true;
            this.AllowIncomplete = true;
            this.AllowNotPanar = true;
            this.AllowMultiEdge = true;
        }

        public void Build()
        {

            //this.BinaryMatrix = new Dictionary<Vertex<T>, bool[]>();
            //this.WeightedMatrix = new Dictionary<Vertex<T>, decimal[]>();
            //this.List = new List<LinkedList<Vertex<T>>>();
            switch (this.Layout)
            {
                case LayoutType.BinaryMatrix:
                    //this.GraphLayout = new BinaryMatrix<T>();
                    this.GraphLayout = new MatrixLayout<T>(this.Nodes,this.Edges);
                    break;
                case LayoutType.WeightedMatrix:
                    this.GraphLayout = new MatrixLayout<T>(this.Nodes, this.Edges);
                    //this.GraphLayout = new WeightedMatrix<T>();
                    break;
                case LayoutType.List:
                    this.GraphLayout = new ListLayout<T>(this.Nodes, this.Edges);
                    break;
                default:
                    break;
            }
            //build graphlayout
        }



        public void AddNode()
        {
            
        }

        public void AddEdge()
        {

        }

        public void DeleteNode()
        {
        }

        public void DeleteEdge()
        {

        }




        //createGraph()
        //addNode(newItem)
        //addEdge(Node1, Node2)
        //isEmpty
        //isLink (Node1,Node2)
        //deleteNode(Node)
        //deleteEdge(Node1,Node2)
        //getAdjencyNodes(Node)

        //successors
        //predesessors

        //choosing DataStructure
        //Frequent operations:
        //–Are two vertices adjacent?
        //–Get all vertices adjacent to a given vertex
        //•Heuristics:
        //–Sparse graph (e close to n) => adjacency-list
        //–Dense graph (e close to n2) => adjacency-matrix
        //–Biased distribution of the frequency of operations (HasEdge and GetAdjacenciesTo) may change these rules of thumb.
    }
    public interface IGraphLayout<T>
    {
        //void Add(Vertex<T> node, decimal[] weight);
    }
    public class GraphLayout<T>:IGraphLayout<T>
    {
        //public void Add(Vertex<T> node, decimal[] weight);
    }

    public class MatrixLayout<T> : GraphLayout<T>
    {
        public Dictionary<Vertex<T>, decimal[]> Layout{ get; set; }

        public MatrixLayout(List<Vertex <T>> nodes, List<Edge<T>> edges)
        {
            foreach (var n in nodes)
            {
                
                decimal[] e;

                this.Layout.Add(n,e);
            }
        }

        //public void Add(Vertex<T> node, decimal[] weight);

    }

    public class ListLayout<T> : GraphLayout<T>
    {
        public List<LinkedList<Vertex<T>>> Layout { get; set; } // List

        public ListLayout(List<Vertex <T>> nodes, List<Edge<T>> edges)
        {
        }
        //public void Add(Vertex<T> node, decimal[] weight);

    }

    public class Vertex<T>
    {
        public int Index { get; set; }
        public int Degree { get; set; } //number of edges incident to verex
        public Vertex<T> Successor { get; set; }
        public Vertex<T> Predecessor { get; set; }
        public T Item { get; set; }
        public decimal Cost { get; set; }
    }

    public class Edge<T>
    {
        public Vertex<T> Origin { get; set; }
        public Vertex<T> Destination { get; set; }
        public bool IsDirected { get; set; }
        public decimal Weight { get; set; }
    }

    public class Path<T>
    {
        public bool IsSimple { get; set; } // true if no vertices(and edges) are repeated
        public bool IsTrail { get; set; } //true if no edgs are repeated (vertices can be repeated)
        public bool IsClosed { get; set; } //closed walk ends and starts at same point and greater than 0
        public int Length { get; set; } // number of edges in the path
        public bool IsCycle { get; set; } // no edges or vertices repeat but start and end vertices


        public Vertex<T> Start { get; set; }
        public Vertex<T> End { get; set; }
        public LinkedList<Vertex<T>> Walk { get; set; }

        public Vertex<T> GetStart()
        {
            return new Vertex<T>();
        }
        public Vertex<T> GetEnd()
        {
            return new Vertex<T>();
        }
    }
    public class Pathfinder<T>
    {
        public Path<T> EulerPath()
        {
            // if there are 0 or 2 vertices of 2 degree
            return new Path<T>();
        }
        public Path<T> HamiltonCircuit()
        {
            //begins at a vertex v, passes through every vertex exactly once, and terminates at v.
            return new Path<T>();
        }
    }
}
