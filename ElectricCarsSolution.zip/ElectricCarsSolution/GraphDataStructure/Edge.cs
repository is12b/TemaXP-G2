﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphLibrary
{
    public class Edge
    {
        private Vertex _from;
        private Vertex _to;

        public Edge(Vertex from, Vertex to)
        {
            this._from = from;
            this._to = to;
        }

        public Vertex From
        {
            get
            {
                return _from;
            }
        }

        public Vertex To
        {
            get
            {
                return _to;
            }
        }
    }
}