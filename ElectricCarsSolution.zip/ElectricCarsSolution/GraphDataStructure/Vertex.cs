﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphLibrary
{
    public class Vertex
    {
        private string _name;
        private bool _mark;

        public Vertex(string name)
        {
            _mark = false;
            this._name = name;

        }

        public override string ToString()//For debugging purposes
        {
            return Name + "  " + Mark;
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public bool Mark
        {
            get
            {
                return _mark;
            }
            set
            {
                _mark = value;
            }
        }
    }
}
