﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphLibrary
{
    public class WGraphAdjList:IWeightedGraph
    {


        //void AddVertex(Vertex vertex);
        //void AddEdge(Vertex startVertex, Vertex endVertex, decimal weight);
        //bool ContainsVertex(Vertex vertex);
        //bool IsAdjacent(Vertex startVertex, Vertex endVertex);
        //ICollection<Vertex> GetAdjacencies(Vertex vertex);
        //IEnumerator<Vertex> Vertices();
        //bool IsEmpty();
        //int GetNoOfVertices();
        //int GetNoOfEdges();
        //void Clear();
        private IList<Vertex> _vertices;
        private IList<LinkedList<Edge>> _adjlists;


        public WGraphAdjList()
        {
            _vertices = new List<Vertex>();
            _adjlists = new List<LinkedList<Edge>>();
        }

        public bool IsEmpty()
        {
            return _vertices.Count == 0;
        }

        public void AddVertex(Vertex v)
        {
            _vertices.Add(v);
            _adjlists.Add(new LinkedList<Edge>());
        }

        public void AddEdge(Vertex from, Vertex to)
        {

            int fromInx = _vertices.IndexOf(from);
            _adjlists[fromInx].AddLast(new Edge(from,to));
        }
        
        public void AddEdge(Edge ed)
        {

            int fromInx = _vertices.IndexOf(ed.From);
            _adjlists[fromInx].AddLast(ed);
        }


        public bool ContainsVertex(Vertex vertex)
        {
            return _vertices.Contains(vertex);
        }

        public bool IsAdjacent(Vertex startVertex, Vertex endVertex)
        {
            throw new System.NotImplementedException();
        }


        public ICollection<Vertex> GetAdjacencies(Vertex vertex)
        {
            int vertexInx = _vertices.IndexOf(vertex);
            ICollection<Vertex> adjvertices = new List<Vertex>();
            foreach(Edge e in _adjlists[vertexInx])
            {
                adjvertices.Add(e.To);
            }
            return adjvertices;
        }


        public IEnumerator<Vertex> Vertices()
        {
            return _vertices.GetEnumerator();
        }

        public int GetNoOfVertices()
        {
            return _vertices.Count;

        }

        public int GetNoOfEdges()
        {
            throw new System.NotImplementedException();
        }

        public void Unmark()
        {
            {
                foreach (Vertex v in _vertices)
                    v.Mark = false;
            }
        }

        public void Clear()
        {
            _vertices = new List<Vertex>();
            _adjlists = new List<LinkedList<Edge>>();
        }
    }
}
