﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphLibrary
{
    public class IWeightedGraph
    {

        void AddVertex(Vertex vertex);
        void AddEdge(Vertex startVertex, Vertex endVertex, decimal weight);
        bool ContainsVertex(Vertex vertex);
        bool IsAdjacent(Vertex startVertex, Vertex endVertex);
        ICollection<Vertex> GetAdjacencies(Vertex vertex);
        IEnumerator<Vertex> Vertices();
        bool IsEmpty();
        int GetNoOfVertices();
        int GetNoOfEdges();
        void Clear();

        //void Bfs(Vertex v);
        //void Dfs(Vertex v);
        //void DfsRS(Vertex v);
        //void BfsSpanningTree(Vertex v);
        //void DfsSpanningTree(Vertex v);
        //void Unmark();
    }
}
