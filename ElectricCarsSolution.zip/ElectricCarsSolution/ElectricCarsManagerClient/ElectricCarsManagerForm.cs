﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricCarsManagerClient.ElectricCarsManagerServiceReference;

namespace ElectricCarsManagerClient
{
    public partial class ElectricCarsManagerForm : Form
    {
        public static IElectricCarsManagerService proxy = new ElectricCarsManagerServiceClient();

        public ElectricCarsManagerForm()
        {
            InitializeComponent();
            this.Login(1115,"");
            BindBatteries();
        }
        protected void BindBatteries()
        {
            //this.dgvMain.DataSource = null;
            BindingList<Battery> bindingList = new BindingList<Battery>(proxy.GetBatteries());
            this.dgvMain.DataSource = bindingList;
        }
        protected void Login(int id, string access)
        {
            proxy.LogIn(id,access);
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvMain.SelectedRows)
            {
                int id = Convert.ToInt32(row.Cells["idDataGridViewTextBoxColumn"].Value);
                proxy.ChangeBattery(id);
                this.BindBatteries();
            }
        }
    }
}
