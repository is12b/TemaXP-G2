﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ElectricCarsWebClient.ElectricCarsUserServiceReference;
using ElectricCarsWebClient.Templates;

namespace ElectricCarsWebClient
{
    public partial class Default : System.Web.UI.Page
    {
        //public static IElectricCarsUserService proxy = new ElectricCarsUserServiceClient();
        public static IElectricCarsUserService proxy = new ElectricCarsUserServiceClient();
        private List<Location> locations;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                locations = proxy.GetLocations().ToList();
                this.BindLocations(ddlFrom);
                this.BindLocations(ddlTo);
                this.ClearPath();
            }
        }

        protected void BindLocations(DropDownList ddl)
        {
            ddl.Items.Clear();
            ddl.Items.Add(new ListItem(" -- Select location --","0"));
            foreach (Location l in this.locations)
            {
                string name = String.Format("{3}:{0} ({1}; {2})", l.Name, l.DisplayLongitude, l.DisplayLatitude, l.Id);
                ddl.Items.Add(new ListItem(name,l.Id.ToString()));
            }
        }

        protected void btnFindPath_Click(object sender, EventArgs e)
        {
            int start = Convert.ToInt32(this.ddlFrom.SelectedValue);
            int end = Convert.ToInt32(this.ddlTo.SelectedValue);
            this.ltTest.Text = String.Format("{0},{1}", start, end);
            //make sure we dont walk in circles
            if (start!=end)
            {
                Path path = proxy.GetPath(start, end);
                if (path!=null)
                {
                    this.rptPath.DataSource = path.Route;
                    this.rptPath.DataBind();
                    if (path.Stations.Count() > 0)
                    {
                        this.btnBook.Visible = true;
                    }
                }
            }
            else
            {
                this.ltResult.Text = "Choose destination different from start point";
            }
        }
        protected string Format(Location loc, bool isStation)
        {
            string result = String.Format("{0}: \"{1}\" @{2};{3}{4}",loc.Id,loc.Name,loc.DisplayLongitude, loc.DisplayLatitude,isStation?"; (Change battery here)":"");
            return result;
        }
        protected void ClearPath()
        {
            this.rptPath.DataSource = null;
            this.rptPath.DataBind();
            this.btnBook.Visible = false;
            this.ltResult.Text = "";
        }

        protected void btnBook_Click(object sender, EventArgs e)
        {
            string bookingCode = proxy.BookBatteries();
            if (bookingCode!="")
            {
                ltResult.Text = String.Format("Your batteries are booked. Your booking code: {0}", bookingCode);
            }
            else
            {
                ltResult.Text = "Failed to book.";
            }
            
        }
    }
}