﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricCarsAdminClient.ElectricCarsAdminServiceReference;

namespace ElectricCarsAdminClient
{
    public partial class ElectricCarsAdminForm : Form
    {
        public static IElectricCarsAdminService proxy = new ElectricCarsAdminServiceClient();
        private List<Location> locations;
        

        public ElectricCarsAdminForm()
        {
            InitializeComponent();
            this.BindLocations();
        }

        public IElectricCarsAdminService GetProxy()
        {
            return proxy;
        }

        public void BindLocations()
        {
            this.locations = proxy.GetLocations().ToList();
            BindingList<Location> bindingList = new BindingList<Location>(locations);
            this.tblLocation.DataSource = bindingList;
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ElectricCarsAdminDialog dialog = new ElectricCarsAdminDialog(null, DialogType.ADD, this);
            dialog.ShowDialog();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ElectricCarsAdminDialog dialog = new ElectricCarsAdminDialog(this.getSelection(), DialogType.EDIT, this);
            dialog.ShowDialog();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ElectricCarsAdminDialog dialog = new ElectricCarsAdminDialog(this.getSelection(), DialogType.DELETE, this);
            dialog.ShowDialog();

        }
        private Location getSelection()
        {
            int countRows = this.tblLocation.SelectedRows.Count;
            int id = 0;
            if (countRows==1)
            {
                DataGridViewRow row = this.tblLocation.SelectedRows[0];
                id = Convert.ToInt32(row.Cells["idDataGridViewTextBoxColumn"].Value);

            }
            return locations.FirstOrDefault(x=>x.Id == id);
        }
    }
}
