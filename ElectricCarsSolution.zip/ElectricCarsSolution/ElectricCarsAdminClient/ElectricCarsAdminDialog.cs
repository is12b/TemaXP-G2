﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using ElectricCarsAdminClient.ElectricCarsAdminServiceReference;

namespace ElectricCarsAdminClient
{
    public enum DialogType
    {
        DELETE,
        EDIT,
        ADD
    }
    public partial class ElectricCarsAdminDialog : Form
    {
        private ElectricCarsAdminForm mainForm;
        private Location location;
        private DialogType type;
        private static IElectricCarsAdminService proxy;

        private List<Location> locations;
        private List<Link> links;


        public ElectricCarsAdminDialog (Location l, DialogType t, ElectricCarsAdminForm f)
        {
            //save data here
            this.mainForm = f;
            this.location = l;
            this.type = t;
            
            //get proxy
            proxy = this.mainForm.GetProxy();

            //get list of locations from server
            this.locations = proxy.GetLocations().ToList();

            // if location was assigned (were are not running in "create new" mode)
            if (location !=null)
            {
                this.SetLinks();
            }
            else // if location wasnt given declare empty list of links
            {
                this.links = new List<Link>();
            }

            // declare form and components
            InitializeComponent();

            // make sure all fields are clear
            this.ClearForm();

            //adjust interface to the form type
            switch (this.type)
            {
                case DialogType.DELETE:
                    this.DisableForm();
                    this.HideBatteriesCount();
                    this.btnConfirm.Text = "Delete";
                    break;
                case DialogType.EDIT:
                    this.HideBatteriesCount();
                    this.btnConfirm.Text = "Save";
                    break;
                case DialogType.ADD:
                    this.btnConfirm.Text = "Save";
                    break;
                default:
                    break;
            }
            // bind location to form
            this.BindItem();
            
        }
        private void SetLinks()
        {
            if (location != null)
            {
                // get list of links related to this location
                this.links = proxy.GetLinksByLocation(this.location.Id).ToList();

                // make sure that 1st location in link isnt our location
                // but neighbor
                foreach (Link link in this.links)
                {
                    if (link.Location1.Id == this.location.Id)
                    {
                        link.Location1 = link.Location2;
                        link.Location2 = this.location;
                    }
                }
            }
        }
        /// <summary>
        /// Binds locations to links group
        /// </summary>
        private void BindLocations()
        {
            // bind locations
            this.ddlLocation.Items.Clear();
            this.ddlLocation.DisplayMember = "Text";
            this.ddlLocation.ValueMember = "Value";
            BindingList<ListItem> bl = new BindingList<ListItem>();

            foreach (Location l in locations)
            {
                string name = String.Format("{3}:{0} ({1}; {2})", l.Name, l.DisplayLongitude, l.DisplayLatitude, l.Id);
                ListItem item = new ListItem();
                item.Text = name;
                item.Value = l.Id.ToString();
                bl.Add(item);
            }

            this.ddlLocation.DataSource = bl;
        }

        /// <summary>
        /// Sets all textfields in form empty
        /// </summary>
        private void ClearForm()
        {
            this.txtAddress.Text = "";
            this.txtBatteriesCount.Text = "";
            this.txtCity.Text = "";
            this.txtLatitude.Text = "";
            this.txtLongitude.Text = "";
            this.txtName.Text = "";
            this.txtZip.Text = "";
            this.BindLocations();
            this.ClearLinkForm();
        }
        private void ClearLinkForm()
        {
            this.ddlLocation.SelectedIndex = 0;
            this.txtTime.Text = "00:00:00";
            this.txtDistance.Text = "0";
        }

        /// <summary>
        /// Disable all fields
        /// </summary>
        private void DisableForm()
        {
            this.txtAddress.Enabled = false;
            this.txtBatteriesCount.Enabled = false;
            this.txtCity.Enabled = false;
            this.txtLatitude.Enabled = false;
            this.txtLongitude.Enabled = false;
            this.txtName.Enabled = false;
            this.txtZip.Enabled = false;
            this.txtTime.Enabled = false;
            this.txtDistance.Enabled = false;
            this.ddlLocation.Enabled = false;
            this.btnAddLink.Enabled = false;

            this.btnRemoveLink.Enabled = false;
            this.tblLinks.Enabled = false;
        }

        /// <summary>
        /// Hide BatteriesCount text field and label
        /// </summary>
        private void HideBatteriesCount()
        {
            this.txtBatteriesCount.Text = "";
            this.txtBatteriesCount.Visible = false;
            this.lblBatteriesCount.Visible = false;
        }

        /// <summary>
        /// Fill fields with location data if location isnt null
        /// </summary>
        private void BindItem()
        {
            if (this.location!=null)
            {
                this.txtAddress.Text = this.location.Address;
                this.txtBatteriesCount.Text = "1";
                this.txtCity.Text = this.location.Zip.City;
                this.txtLatitude.Text = this.location.Latitude.ToString();
                this.txtLongitude.Text = this.location.Longitude.ToString();
                this.txtName.Text = this.location.Name;
                this.txtZip.Text = this.location.Zip.Code.ToString();
                this.BindLinks();
            }
        }
        private void CloseForm()
        {
            this.Dispose();
            this.Close();
        }
        /// <summary>
        /// Binds links assosiated with given location to links datagridview
        /// </summary>
        private void BindLinks()
        {
            BindingList<Link> bindingList = new BindingList<Link>(links);
            this.tblLinks.DataSource = bindingList;
        }

        /// <summary>
        /// Fill location with given in form data
        /// </summary>
        private void BuildLocation()
        {
            // define new location if doesnt exist
            if (this.location == null)
            {
                this.location = new Location();
                this.location.Id = 0;

            }
            this.location.Name = this.txtName.Text;
            this.location.Latitude = this.txtLatitude.Text == "" ? 0 : Convert.ToDecimal(this.txtLatitude.Text);
            this.location.Longitude = this.txtLongitude.Text == "" ? 0 : Convert.ToDecimal(this.txtLongitude.Text);
            this.location.Address = this.txtAddress.Text;

            // Define new zip if doesnt exist
            if (this.location.Zip == null)
            {
                this.location.Zip = new Zip();
            }
            this.location.Zip.Code = this.txtZip.Text == "" ? 0 : Convert.ToInt32(this.txtZip.Text);
            this.location.Zip.City = this.txtCity.Text;

        }
        /// <summary>
        /// Get link id in datagridview and return link from existing link list
        /// </summary>
        /// <returns></returns>
        private Link GetSelection()
        {
            int countRows = this.tblLinks.SelectedRows.Count;
            Location loc = null;
            if (countRows == 1)
            {
                DataGridViewRow row = this.tblLinks.SelectedRows[0];
                loc = (Location)(row.Cells["dgvLocation1Column"].Value);

            }
            return links.FirstOrDefault(x => x.Location1.Id == loc.Id);
        }
        /******************************
         *      EVENTS
         * ****************************/
        /// <summary>
        /// Adds new link to assosiated location with given data 
        /// if location exists 
        /// else creates a dummy location 
        /// and adds to links list for later association
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddLink_Click(object sender, EventArgs e)
        {
            // get data from form
            int locationId = Convert.ToInt32(this.ddlLocation.SelectedValue);
            decimal distance = Convert.ToDecimal(this.txtDistance.Text);
            string[] time = this.txtTime.Text.Split(':');
            int hr = Convert.ToInt32(time[0]);
            int min = Convert.ToInt32(time[1]);
            int sec = Convert.ToInt32(time[2]);

            //associate data with new link object
            Link link = new Link();

            // find location in existing location list that matches selected id
            link.Location1 = this.locations.FirstOrDefault(x => x.Id == locationId);

            if (this.location != null)//if our location exists
            {
                link.Location2 = this.location;//put it in second slot
            }

            link.Time = new TimeSpan(hr, min, sec); // set time
            link.Distance = distance; // set distance
            

            // what to do with link in different modes
            switch (this.type)
            {
                case DialogType.EDIT:
                    // if location is given go straight for database
                    // else we will have trouble comparing the old set with new one
                    proxy.CreateLink(link);
                    break;
                case DialogType.ADD:
                    // if we creating new location we dont have it in db yet
                    // therefore cannot set as a valid one into link
                    // make sure we have some kind of location 
                    // to associate the link with  
                    this.BuildLocation();
                    link.Location2 = this.location;
                    this.links.Add(link);
                    break;
                default:
                    break;
            }
            // refresh data grid view
            this.BindLinks();
        }
        private void btnRemoveLink_Click(object sender, EventArgs e)
        {
            Link l = GetSelection();
            switch (this.type)
            {
                case DialogType.EDIT:
                    proxy.DeleteLink(l);
                    this.SetLinks();
                    this.BindLinks();
                    break;
                case DialogType.ADD:
                    this.links.Remove(l);
                    this.BindLinks();
                    break;
                default:
                    break;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.CloseForm();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            this.BuildLocation();
            switch (this.type)
            {
                case DialogType.DELETE:
                    proxy.DeleteLocation(this.location);
                    break;
                case DialogType.EDIT:
                    proxy.UpdateLocation(this.location);
                    break;
                case DialogType.ADD:
                    proxy.AddLocation(this.location,this.links.ToArray(), Convert.ToInt32(this.txtBatteriesCount.Text));
                    break;
                default:
                    break;
            }
            this.CloseForm();
            this.mainForm.BindLocations();
        }

    }

    /***********************************************
     *  Custom link column for data grid view
     * ********************************************/

    public class LinkLocationCell : DataGridViewTextBoxCell
    {
        protected override void Paint(Graphics graphics, Rectangle clipBounds, Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
        {
            Location loc = (Location)value;
            formattedValue = String.Format("{0}:\"{1}\" ({2})", loc.Id, loc.Name, loc.DisplayAddress);
            base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, paintParts);
        }
    }
    public class LinkLocationColumn : DataGridViewColumn
    {
        public LinkLocationColumn()
        {
            this.CellTemplate =
              new LinkLocationCell();
            this.ReadOnly = true;
        }
    }


}
