﻿namespace ElectricCarsAdminClient
{
    partial class ElectricCarsAdminDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLatitude = new System.Windows.Forms.Label();
            this.txtLatitude = new System.Windows.Forms.TextBox();
            this.lblLongitude = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtBatteriesCount = new System.Windows.Forms.TextBox();
            this.lblBatteriesCount = new System.Windows.Forms.Label();
            this.ddlLocation = new System.Windows.Forms.ComboBox();
            this.btnAddLink = new System.Windows.Forms.Button();
            this.tblLinks = new System.Windows.Forms.DataGridView();
            this.colLinkLocation = new ElectricCarsAdminClient.LinkLocationColumn();
            this.dgvLocation1Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.linkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtLongitude = new System.Windows.Forms.TextBox();
            this.gbLinks = new System.Windows.Forms.GroupBox();
            this.btnRemoveLink = new System.Windows.Forms.Button();
            this.txtDistance = new System.Windows.Forms.TextBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.lblDistance = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblLocation = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.locationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.linkLocationColumn1 = new ElectricCarsAdminClient.LinkLocationColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tblLinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linkBindingSource)).BeginInit();
            this.gbLinks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(118, 9);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 20);
            this.txtName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLatitude
            // 
            this.lblLatitude.Location = new System.Drawing.Point(324, 8);
            this.lblLatitude.Name = "lblLatitude";
            this.lblLatitude.Size = new System.Drawing.Size(100, 20);
            this.lblLatitude.TabIndex = 2;
            this.lblLatitude.Text = "Latitude:";
            this.lblLatitude.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtLatitude
            // 
            this.txtLatitude.Location = new System.Drawing.Point(430, 8);
            this.txtLatitude.Name = "txtLatitude";
            this.txtLatitude.Size = new System.Drawing.Size(75, 20);
            this.txtLatitude.TabIndex = 3;
            // 
            // lblLongitude
            // 
            this.lblLongitude.Location = new System.Drawing.Point(324, 34);
            this.lblLongitude.Name = "lblLongitude";
            this.lblLongitude.Size = new System.Drawing.Size(100, 20);
            this.lblLongitude.TabIndex = 4;
            this.lblLongitude.Text = "Longitude:";
            this.lblLongitude.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(118, 35);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(200, 20);
            this.txtAddress.TabIndex = 6;
            // 
            // lblAddress
            // 
            this.lblAddress.Location = new System.Drawing.Point(12, 33);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(100, 20);
            this.lblAddress.TabIndex = 7;
            this.lblAddress.Text = "Address:";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(118, 61);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(69, 20);
            this.txtZip.TabIndex = 8;
            // 
            // lblZipCode
            // 
            this.lblZipCode.Location = new System.Drawing.Point(12, 61);
            this.lblZipCode.Name = "lblZipCode";
            this.lblZipCode.Size = new System.Drawing.Size(100, 20);
            this.lblZipCode.TabIndex = 9;
            this.lblZipCode.Text = "ZipCode:";
            this.lblZipCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(193, 61);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(125, 20);
            this.txtCity.TabIndex = 10;
            // 
            // txtBatteriesCount
            // 
            this.txtBatteriesCount.Location = new System.Drawing.Point(430, 60);
            this.txtBatteriesCount.Name = "txtBatteriesCount";
            this.txtBatteriesCount.Size = new System.Drawing.Size(75, 20);
            this.txtBatteriesCount.TabIndex = 11;
            // 
            // lblBatteriesCount
            // 
            this.lblBatteriesCount.Location = new System.Drawing.Point(324, 60);
            this.lblBatteriesCount.Name = "lblBatteriesCount";
            this.lblBatteriesCount.Size = new System.Drawing.Size(100, 20);
            this.lblBatteriesCount.TabIndex = 12;
            this.lblBatteriesCount.Text = "Batteries count:";
            this.lblBatteriesCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ddlLocation
            // 
            this.ddlLocation.FormattingEnabled = true;
            this.ddlLocation.Location = new System.Drawing.Point(67, 21);
            this.ddlLocation.Name = "ddlLocation";
            this.ddlLocation.Size = new System.Drawing.Size(420, 21);
            this.ddlLocation.TabIndex = 14;
            // 
            // btnAddLink
            // 
            this.btnAddLink.Location = new System.Drawing.Point(412, 46);
            this.btnAddLink.Name = "btnAddLink";
            this.btnAddLink.Size = new System.Drawing.Size(75, 23);
            this.btnAddLink.TabIndex = 15;
            this.btnAddLink.Text = "Add Link";
            this.btnAddLink.UseVisualStyleBackColor = true;
            this.btnAddLink.Click += new System.EventHandler(this.btnAddLink_Click);
            // 
            // tblLinks
            // 
            this.tblLinks.AllowUserToAddRows = false;
            this.tblLinks.AllowUserToDeleteRows = false;
            this.tblLinks.AutoGenerateColumns = false;
            this.tblLinks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblLinks.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colLinkLocation,
            this.dgvLocation1Column,
            this.distanceDataGridViewTextBoxColumn,
            this.timeDataGridViewTextBoxColumn});
            this.tblLinks.DataSource = this.linkBindingSource;
            this.tblLinks.Location = new System.Drawing.Point(6, 75);
            this.tblLinks.Name = "tblLinks";
            this.tblLinks.ReadOnly = true;
            this.tblLinks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblLinks.Size = new System.Drawing.Size(481, 121);
            this.tblLinks.TabIndex = 13;
            // 
            // colLinkLocation
            // 
            this.colLinkLocation.DataPropertyName = "Location1";
            this.colLinkLocation.HeaderText = "Link Location";
            this.colLinkLocation.Name = "colLinkLocation";
            this.colLinkLocation.ReadOnly = true;
            this.colLinkLocation.Width = 200;
            // 
            // dgvLocation1Column
            // 
            this.dgvLocation1Column.DataPropertyName = "Location1";
            this.dgvLocation1Column.HeaderText = "Location1";
            this.dgvLocation1Column.Name = "dgvLocation1Column";
            this.dgvLocation1Column.ReadOnly = true;
            this.dgvLocation1Column.Visible = false;
            // 
            // distanceDataGridViewTextBoxColumn
            // 
            this.distanceDataGridViewTextBoxColumn.DataPropertyName = "Distance";
            this.distanceDataGridViewTextBoxColumn.HeaderText = "Distance";
            this.distanceDataGridViewTextBoxColumn.Name = "distanceDataGridViewTextBoxColumn";
            this.distanceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // timeDataGridViewTextBoxColumn
            // 
            this.timeDataGridViewTextBoxColumn.DataPropertyName = "Time";
            this.timeDataGridViewTextBoxColumn.HeaderText = "Time";
            this.timeDataGridViewTextBoxColumn.Name = "timeDataGridViewTextBoxColumn";
            this.timeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // linkBindingSource
            // 
            this.linkBindingSource.DataSource = typeof(ElectricCarsAdminClient.ElectricCarsAdminServiceReference.Link);
            // 
            // txtLongitude
            // 
            this.txtLongitude.Location = new System.Drawing.Point(430, 34);
            this.txtLongitude.Name = "txtLongitude";
            this.txtLongitude.Size = new System.Drawing.Size(75, 20);
            this.txtLongitude.TabIndex = 16;
            // 
            // gbLinks
            // 
            this.gbLinks.Controls.Add(this.btnRemoveLink);
            this.gbLinks.Controls.Add(this.txtDistance);
            this.gbLinks.Controls.Add(this.txtTime);
            this.gbLinks.Controls.Add(this.lblDistance);
            this.gbLinks.Controls.Add(this.lblTime);
            this.gbLinks.Controls.Add(this.lblLocation);
            this.gbLinks.Controls.Add(this.ddlLocation);
            this.gbLinks.Controls.Add(this.btnAddLink);
            this.gbLinks.Controls.Add(this.tblLinks);
            this.gbLinks.Location = new System.Drawing.Point(12, 88);
            this.gbLinks.Name = "gbLinks";
            this.gbLinks.Size = new System.Drawing.Size(493, 232);
            this.gbLinks.TabIndex = 17;
            this.gbLinks.TabStop = false;
            this.gbLinks.Text = "Links";
            // 
            // btnRemoveLink
            // 
            this.btnRemoveLink.Location = new System.Drawing.Point(372, 203);
            this.btnRemoveLink.Name = "btnRemoveLink";
            this.btnRemoveLink.Size = new System.Drawing.Size(115, 23);
            this.btnRemoveLink.TabIndex = 24;
            this.btnRemoveLink.Text = "Remove Link";
            this.btnRemoveLink.UseVisualStyleBackColor = true;
            this.btnRemoveLink.Click += new System.EventHandler(this.btnRemoveLink_Click);
            // 
            // txtDistance
            // 
            this.txtDistance.Location = new System.Drawing.Point(218, 49);
            this.txtDistance.Name = "txtDistance";
            this.txtDistance.Size = new System.Drawing.Size(77, 20);
            this.txtDistance.TabIndex = 22;
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(67, 47);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(65, 20);
            this.txtTime.TabIndex = 21;
            // 
            // lblDistance
            // 
            this.lblDistance.Location = new System.Drawing.Point(153, 48);
            this.lblDistance.Name = "lblDistance";
            this.lblDistance.Size = new System.Drawing.Size(59, 20);
            this.lblDistance.TabIndex = 20;
            this.lblDistance.Text = "Distance:";
            this.lblDistance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTime
            // 
            this.lblTime.Location = new System.Drawing.Point(6, 48);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(55, 20);
            this.lblTime.TabIndex = 19;
            this.lblTime.Text = "Time:";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLocation
            // 
            this.lblLocation.Location = new System.Drawing.Point(6, 20);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(55, 20);
            this.lblLocation.TabIndex = 18;
            this.lblLocation.Text = "Location:";
            this.lblLocation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(425, 326);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(75, 23);
            this.btnConfirm.TabIndex = 18;
            this.btnConfirm.Text = "Save";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(342, 326);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 19;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // locationBindingSource
            // 
            this.locationBindingSource.DataSource = typeof(ElectricCarsAdminClient.ElectricCarsAdminServiceReference.Location);
            // 
            // linkLocationColumn1
            // 
            this.linkLocationColumn1.DataPropertyName = "Location1";
            this.linkLocationColumn1.HeaderText = "Link Location";
            this.linkLocationColumn1.Name = "linkLocationColumn1";
            this.linkLocationColumn1.ReadOnly = true;
            this.linkLocationColumn1.Width = 200;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Location1";
            this.dataGridViewTextBoxColumn1.HeaderText = "Location1";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Distance";
            this.dataGridViewTextBoxColumn2.HeaderText = "Distance";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Time";
            this.dataGridViewTextBoxColumn3.HeaderText = "Time";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // ElectricCarsAdminDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 361);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.gbLinks);
            this.Controls.Add(this.txtLongitude);
            this.Controls.Add(this.lblBatteriesCount);
            this.Controls.Add(this.txtBatteriesCount);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.lblZipCode);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblLongitude);
            this.Controls.Add(this.txtLatitude);
            this.Controls.Add(this.lblLatitude);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label2);
            this.Name = "ElectricCarsAdminDialog";
            this.Text = "ElectricCarsAdminDialog";
            ((System.ComponentModel.ISupportInitialize)(this.tblLinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linkBindingSource)).EndInit();
            this.gbLinks.ResumeLayout(false);
            this.gbLinks.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLatitude;
        private System.Windows.Forms.TextBox txtLatitude;
        private System.Windows.Forms.Label lblLongitude;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.Label lblZipCode;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtBatteriesCount;
        private System.Windows.Forms.Label lblBatteriesCount;
        private System.Windows.Forms.BindingSource locationBindingSource;
        private System.Windows.Forms.ComboBox ddlLocation;
        private System.Windows.Forms.Button btnAddLink;
        private System.Windows.Forms.DataGridView tblLinks;
        private System.Windows.Forms.TextBox txtLongitude;
        private System.Windows.Forms.GroupBox gbLinks;
        private System.Windows.Forms.Button btnRemoveLink;
        private System.Windows.Forms.TextBox txtDistance;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label lblDistance;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.BindingSource linkBindingSource;
        private LinkLocationColumn colLinkLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvLocation1Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn distanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        private LinkLocationColumn linkLocationColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    }
}