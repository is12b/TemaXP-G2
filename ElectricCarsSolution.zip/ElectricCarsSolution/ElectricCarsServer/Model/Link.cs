﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using ElectricCars.Database;

namespace ElectricCars.Model
{
    [DataContract]
    public class Link:SqlModel
    {
        private LinkDB linDB;
        private LocationDB locDB;

        [DataMember]
        public Location Location1 { get; set; }

        [DataMember]
        public Location Location2 { get; set; }

        [DataMember]
        public decimal Distance { get; set; }

        [DataMember]
        public TimeSpan Time { get; set; }

        public Link()
        {
            this.CreateConnection();
        }

        public void BuildObject(DataRow row)
        {
            this.Location1 = locDB.GetById(SqlFormat.ToInt(row, "location1"));
            this.Location2 = locDB.GetById(SqlFormat.ToInt(row, "location2"));
            this.Distance = SqlFormat.ToDecimal(row, "distance");
            this.Time = SqlFormat.ToTimeSpan(row, "time");
        }
        public Response<Link> Create()
        {
            return this.linDB.Create(this);
        }
        public Response<Link> Update()
        {
//            SqlData data = new SqlData();
//            data.Set("distance", this.Distance);
//            data.Set("time", this.Time);
//            data.WhereClause = String.Format(@"
//                (location1 = {0} AND location2 = {1}) OR
//                (location1 = {1} AND location2 = {0})",
//                Location1.Id, Location2.Id);
            return this.linDB.Update(this);
        }
        public Response<Link> Delete()
        {
            return this.linDB.Delete(this);
        }
        
        /// <summary>
        /// Creates connection on object recived from client
        /// </summary>
        public void CreateConnection()
        {
            this.locDB = new LocationDB();
            this.linDB = new LinkDB();
        }
    }
    public class LinkDB : SqlHandler<Link>
    {
        enum Input
        {
            StartIsNull,
            EndIsNull,
            DistanceIsZero,
            TimeIsLessThanZero,
            StartEndDistnct,
            StartExists,
            EndExists
        }
        private int CheckInput(Link l, params Input[] input)
        {
            this.Response = new Response<Link>();
            int err = 0;
            LocationDB locDB = new LocationDB();
            if (l==null)
            {
                this.Response.AddMessage(ResponseMessage.NullObject);
                err++;
            }
            else
            {
                foreach (Input item in input)
                {
                    switch (item)
                    {
                        case Input.StartIsNull:
                            if (l.Location1 == null)
                            {
                                this.Response.AddMessage(ResponseMessage.NullObject, 
                                    "Start point shall be defined");
                                err++;
                            }
                            break;
                        case Input.EndIsNull:
                            if (l.Location2 == null)
                            {
                                this.Response.AddMessage(ResponseMessage.NullObject, 
                                    "End point shall be defined");
                                err++;
                            }
                            break;
                        case Input.DistanceIsZero:
                            if (l.Distance == 0)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid, 
                                    "Distance cannot be zero.");
                                err++;
                            }
                            break;
                        case Input.TimeIsLessThanZero:
                            int compare = l.Time.CompareTo(new TimeSpan(0, 0, 0));
                            if (compare < 1)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid, 
                                    "Time cannot be zero or negative.");
                                err++;
                            }
                            break;
                        case Input.StartEndDistnct:
                            if (l.Location1 != null && l.Location2 != null)
                            {
                                if (l.Location1.Id == l.Location2.Id)
                                {
                                    this.Response.AddMessage(ResponseMessage.DataInvalid, 
                                        "Start point shall be distinct from end point");
                                    err++;
                                }
                            }
                            break;
                        case Input.StartExists:
                            if (l.Location1 != null)
                            {
                                if (locDB.GetById(l.Location1.Id) == null)
                                {
                                    this.Response.AddMessage(ResponseMessage.DataInvalid, 
                                        "Start point was not found in data");
                                    err++;
                                }
                            }
                            break;
                        case Input.EndExists:
                            if (l.Location2 != null)
                            {
                                if (locDB.GetById(l.Location2.Id) == null)
                                {
                                    this.Response.AddMessage(ResponseMessage.DataInvalid, 
                                        "End point was not found in data");
                                    err++;
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            return err;
        }

        public Response<Link> Delete(Link l)
        {
            int err = this.CheckInput(l,
                Input.EndIsNull,
                Input.StartIsNull);
            if (err < 1)
            {
                // we are fine on this end, lets try to request
                string where = String.Format(@"
                        (location1 = {0} AND location2 = {1}) OR
                        (location1 = {1} AND location2 = {0})",
                    l.Location1.Id, l.Location2.Id);
                this.Delete(where);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.DeleteSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.DeleteHandlerError);
                }
            }
            //return deleted item with response
            this.Response.Item = l;
            //return response
            return this.Response;
        }
        public Response<Link> Create(Link l)
        {
            int err = this.CheckInput(l,
                Input.DistanceIsZero,
                Input.TimeIsLessThanZero,
                Input.StartEndDistnct,
                Input.StartExists,
                Input.EndExists,
                Input.StartIsNull,
                Input.EndIsNull
                );
            if (l.Distance < 0)
            {
                l.Distance = l.Distance * (-1);
            }
            // if no errors encountered, try fit it in
            if (err < 1)
            {
                SqlData data = new SqlData();
                data.Set("location1", l.Location1.Id);
                data.Set("location2", l.Location2.Id);
                data.Set("distance", l.Distance);
                data.Set("time", l.Time);
                this.Insert(data);

                // on our side everything is alright
                // make sure handler has not been naughty
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.CreateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.CreateHandlerError);
                }
            }
            //return object with response
            this.Response.Item = l;
            //return response
            return this.Response;
        }
        public Response<Link> Update(Link l)
        {
            int err = CheckInput(l,
                Input.StartEndDistnct,
                Input.StartIsNull,
                Input.EndIsNull,
                Input.DistanceIsZero);
            if (err<1)
            {
                SqlData data = new SqlData();
                data.Set("distance", l.Distance);
                data.Set("time", l.Time);
                data.WhereClause = String.Format(@"
                    (location1 = {0} AND location2 = {1}) OR
                    (location1 = {1} AND location2 = {0})",
                    l.Location1.Id, l.Location2.Id);
                this.Update(data);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.UpdateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.UpdateHandlerError);
                }
            }
            this.Response.Item = l;
            return this.Response;
        }
        public Response<Link> DeleteBatch(int locationId)
        {
            this.Response = new Response<Link>();

            //there is no need to request if location doesnt exist
            if (locationId>0)
            {
                string where = String.Format(@"location1 = {0} OR location2 = {0}",locationId);
                int rowcount = this.Delete(where);
                if (this.Success)
                {
                    this.Response.Messages.Add(String.Format("Request successful. {0} links deleted.", rowcount));
                    this.Response.Success = true;
                }
                else
                {
                    //something is totally wrong
                    this.Response.Messages.Add("Request failed. Database handler error.");
                }
            }
            else
            {
                this.Response.Messages.Add(String.Format("Location id={0} is invalid.",locationId));
            }
            return this.Response;
        }
        
        public List<Link> GetByLocationId(int id)
        {
            return this.GetAll().Where(x => x.Location1.Id == id || x.Location2.Id == id).ToList();
        }
        public Link GetByBoth(int id1, int id2)
        {
            return this.GetByLocationId(id1).FirstOrDefault(x => x.Location1.Id == id2 || x.Location2.Id == id2);
        }


    }
}
