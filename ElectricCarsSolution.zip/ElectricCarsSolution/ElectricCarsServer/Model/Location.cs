﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using ElectricCars.Database;
using ElectricCars.Handlers;

namespace ElectricCars.Model
{
    [DataContract]
    public class Location:SqlModel
    {
        private ZipDB _zipDB;
        private BatteryDB _batteryDB;
        private LinkDB _linkDB;
        private LocationDB _locDB;
        
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public decimal Longitude { get; set; }

        [DataMember]
        public decimal Latitude { get; set; }

        [DataMember]
        public string Address { get; set; }

        [DataMember]
        public Zip Zip { get; set; }

        [DataMember]
        public string DisplayLongitude { get { return this.ParseLongitude(); } set { } }

        [DataMember]
        public string DisplayLatitude { get { return this.ParseLatitude(); } set { } }

        [DataMember]
        public string DisplayAddress { get { return String.Format("{0}, {1} {2}", this.Address, this.Zip.Code, this.Zip.City); } set { } }
        public Location()
        {
            this.CreateConnection();
        }
        public void BuildObject(DataRow row)
        {
            this.Id = SqlFormat.ToInt(row, "id");
            this.Name = SqlFormat.ToString(row, "name");
            this.Longitude = SqlFormat.ToDecimal(row, "longitude");
            this.Latitude = SqlFormat.ToDecimal(row, "latitude");
            this.Address = SqlFormat.ToString(row, "address");
            this.Zip = this._zipDB.GetByCode(SqlFormat.ToInt(row, "zipcode"));
        }
        public List<Battery> AllBatteries(){ return this._batteryDB.GetByLocationId(this.Id);}
        public List<Battery> FreeBatteries() { return this.AllBatteries().Where(x => x.Booked == false && x.Replaced + Config.BatteryCharge < DateTime.Now).ToList(); }
        public List<Link> Links() { return this._linkDB.GetByLocationId(this.Id); }
        public Link LinkWith(int linkId) { return this._linkDB.GetByBoth(this.Id,linkId); }
        private string ParseLatitude(){ return this.ParseCoord(this.Latitude, this.Latitude < 0 ? "S" : "N"); }
        private string ParseLongitude(){ return this.ParseCoord(this.Longitude, this.Longitude < 0 ? "W" : "E"); }
        public decimal AngleToDecimal(decimal deg, decimal min, decimal sec) { return deg + (min / 60) + (sec / 3600); }
        private string ParseCoord(decimal value,string direction)
        {
            value = Math.Abs(value);
            var degrees = Math.Truncate(value);    
            var minutes = Math.Truncate((value - degrees) * 60);
            var seconds = Math.Truncate((value - minutes) * 60); 
            return String.Format("{0}\xba{1}'{2}\"{3}", degrees, minutes, seconds, direction);
        }

        public Response<Location> Create()
        {
            return this._locDB.Create(this);
        }
        public Response<Location> Update()
        {
            return this._locDB.Update(this);
        }
        public Response<Location> Delete()
        {
            Response<Location> locationResponse;
            // first delete relations
            // a nessesety because frekking MSSQL is being a 
            // pain the the arse about double foreign key constrains
            Response<Link> linkResponse = this._linkDB.DeleteBatch(this.Id);
            if (linkResponse.Success)
            {
                locationResponse = this._locDB.Delete(this);
            }
            else
            {
                locationResponse = new Response<Location>();
                locationResponse.Messages = linkResponse.Messages;
                locationResponse.Messages.Add("Failed to delete location.");
            }
            return locationResponse;
        }
        /// <summary>
        /// Created connection on object recived from client.
        /// </summary>
        public void CreateConnection()
        {
            this._zipDB = new ZipDB();
            this._batteryDB = new BatteryDB();
            this._linkDB = new LinkDB();
            this._locDB = new LocationDB();
        }
    }

    public class LocationDB:SqlHandler<Location>
    {
        enum Input
        {
            LongitudeIsInRange,
            LatitudeIsInRange,
            LocationExists,
            ZipIsValid
        }
        private SqlData SetData(Location l)
        {
            SqlData data = new SqlData();
            data.Set("name", l.Name);
            data.Set("longitude", l.Longitude);
            data.Set("latitude", l.Latitude);
            data.Set("address", l.Address);

            //cover our arse for null exception
            if (l.Zip != null)
            {
                data.Set("zipcode", l.Zip.Code);
            }
            else
            {
                data.Set("zipcode", SqlSystemValue.SqlNull);
            }
            return data;
        }
        private int CheckInput(Location l, params Input[] inputs)
        {
            int err = 0;
            this.Response = new Response<Location>();
            if (l==null)
            {
                this.Response.AddMessage(ResponseMessage.NullObject);
                err++;
            }
            else
            {
                foreach (Input i in inputs)
                {
                    switch (i)
                    {
                        case Input.LatitudeIsInRange:
                            if (l.Latitude>=-90 && l.Latitude <=90)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid,
                                    "Latitude shall be in range between -90 and 90 degrees");
                                err++;
                            }
                            break;
                        case Input.LongitudeIsInRange:
                            if (l.Latitude >= -180 && l.Latitude <= 180)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid,
                                    "Longitude shall be in range between -180 and 180 degrees");
                                err++;
                            }
                            break;
                        case Input.LocationExists:
                            LocationDB locDB = new LocationDB();
                            if (locDB.GetById(l.Id) == null)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid,
                                    String.Format("Could not find location with id = {0}",l.Id));
                                err++;
                            }
                            break;
                        case Input.ZipIsValid:
                            if (l.Zip!=null)
                            {
                                ZipDB zipDB = new ZipDB();
                                if (zipDB.GetByCode(l.Zip.Code) == null)
                                {
                                    Response<Zip> zipResponse = l.Zip.Create();
                                    foreach (string message in zipResponse.Messages)
                                    {
                                        this.Response.Messages.Add(message);
                                    }
                                    if (!zipResponse.Success)
                                    {
                                        err++;
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            return err;
        }
        public Response<Location> Delete(Location l)
        {
            this.Response = new Response<Location>();
            if (l!= null)
            {
                int rowsAffected = this.Delete(l.Id);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.DeleteSuccess,rowsAffected.ToString());
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.DeleteHandlerError);
                }
            }
            else
            {
                this.Response.AddMessage(ResponseMessage.NullObject);
            }
            return this.Response;
        }
        public Response<Location> Create(Location l)
        {
            int err = this.CheckInput(l, Input.LongitudeIsInRange, Input.LatitudeIsInRange, Input.ZipIsValid);
            if (err<1)
            {
                SqlData data = this.SetData(l);
                l.Id = this.InsertScopeId(data);

                // on our side everything is alright
                // make sure handler has not been naughty
                if (this.Success)
                {
                    if (l.Id > 0)
                    {
                        this.Response.AddMessage(ResponseMessage.CreateSuccess);
                        this.Response.Success = true;
                    }
                    else
                    {
                        this.Response.AddMessage(ResponseMessage.CreateUnknown);
                    }

                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.CreateHandlerError);
                }
            }
            this.Response.Item = l;
            return this.Response;
        }
        public Response<Location> Update(Location l)
        {
            int err = this.CheckInput(l,
                Input.LatitudeIsInRange, 
                Input.LongitudeIsInRange,
                Input.LocationExists,
                Input.ZipIsValid);

            if (err<1)
            {
                SqlData data = this.SetData(l);
                this.Update(data, l.Id);
            }

            this.Response.Item = l;
            return this.Response;
        }
        public Location GetById(int id)
        {
            return this.GetAll().FirstOrDefault(x => x.Id == id);
        }
        public Location GetMinLongitude()
        {
            return this.GetAll().OrderBy(x => x.Longitude).First();
        }
        public Location GetMaxLongitude()
        {
            return this.GetAll().OrderByDescending(x => x.Longitude).First();
        }
        public Location GetMinLatitude()
        {
            return this.GetAll().OrderBy(x => x.Latitude).First();
        }
        public Location GetMaxLatitude()
        {
            return this.GetAll().OrderByDescending(x => x.Latitude).First();
        }
    }
}
