﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using ElectricCars.Database;

namespace ElectricCars.Model
{
    [DataContract]
    public class Zip:SqlModel
    {
        private ZipDB _zipDB;
        [DataMember]
        public int Code { get; set; }
        [DataMember]
        public string City { get; set; }

        public Zip()
        {
            this._zipDB = new ZipDB();
        }

        public void BuildObject(DataRow row)
        {
            this.Code = SqlFormat.ToInt(row, "code");
            this.City = SqlFormat.ToString(row, "city");
        }

        public Response<Zip> Create()
        {
            return this._zipDB.Create(this);
        }
        public Response<Zip> Update()
        {
           return this._zipDB.Update(this);
        }
        public Response<Zip> Delete()
        {
            return this._zipDB.Delete(this);
        }

    }
    public class ZipDB : SqlHandler<Zip>
    {
        enum Input
        {
            CodeIsValid,
            CityIsEmpty
        }
        private int CheckInput(Zip z, params Input[] input)
        {
            this.Response = new Response<Zip>();
            int err = 0;
            if (z==null)
            {
                this.Response.AddMessage(ResponseMessage.NullObject);
                err++;
            }
            else
            {
                foreach (Input i in input)
                {
                    switch (i)
                    {
                        case Input.CodeIsValid:
                            if (z.Code < 1000 && z.Code > 9999)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid,
                                    "Zip code shall be 4 digit");
                                err++;
                            }
                            break;
                        case Input.CityIsEmpty:
                            if (z.City == "")
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid,
                                    "City cannot be empty");
                                err++;
                            }
                            break;
                        default:
                            break;
                    }
                }

            }
            return err;
        }
        public Response<Zip> Create(Zip z)
        {
            int err = this.CheckInput(z, Input.CityIsEmpty, Input.CodeIsValid);
            if (err < 1)
            {
                SqlData data = new SqlData();
                data.Set("code", z.Code);
                data.Set("city", z.City);
                z.Code = this.Insert(data);

                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.CreateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.CreateHandlerError);
                }
            }

            this.Response.Item = z;
            return this.Response;
        }
        public Response<Zip> Update(Zip z)
        {
            int err = CheckInput(z, Input.CityIsEmpty);
            if (err<1)
            {
                SqlData data = new SqlData();
                data.Set("city", z.City);
                data.WhereClause = String.Format("code = {0}", z.Code);
                this.Update(data);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.UpdateSuccess);
                    this.Response.Success = true;
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.UpdateHandlerError);
                }
            }
            this.Response.Item = z;
            return this.Response;
        }
        public Response<Zip> Delete(Zip z)
        {
            this.Response = new Response<Zip>();
            //return deleted object with response

            if (z==null)
            {
                //this.Response.Messages.Add("Zip is not defined. The object is null.");
                this.Response.AddMessage(ResponseMessage.NullObject);
            }
            else
            {
                int rowCount = this.Delete(z.Code, "code");
                if (this.Success)
                {
                    //this.Response.Messages.Add(String.Format("Zip is deleted. {} rows affected.", rowCount));
                    //this.Response.Success = true;
                    this.Response.AddMessage(ResponseMessage.DeleteSuccess, rowCount.ToString());
                }
                else
                {
                    //this.Response.Messages.Add("Could not delete Zip. Database handler error.");
                    this.Response.AddMessage(ResponseMessage.HandlerError);
                }
            }

            this.Response.Item = z;
            //return response
            return this.Response;
        }

        public Zip GetByCode(int code)
        {
            return this.GetAll().FirstOrDefault(x => x.Code == code);
        }
    }
}
