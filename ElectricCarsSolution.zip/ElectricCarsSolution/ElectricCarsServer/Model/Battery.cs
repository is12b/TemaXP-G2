﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using ElectricCars.Database;
using ElectricCars.Handlers;

namespace ElectricCars.Model
{
    public class Battery:SqlModel
    {
        private LocationDB locDB;
        private BookingDB booDB;
        private BatteryDB batDB;

        public int Id { get; set; }
        public Location Location { get; set; }
        public DateTime Replaced { get; set; }
        public bool Booked { get; set; }
        public Booking Booking { get; set; }

        public Battery()
        {
            this.locDB = new LocationDB();
            this.booDB = new BookingDB();
            this.batDB = new BatteryDB();
        }
        public void BuildObject(DataRow row)
        {
            this.Id = SqlFormat.ToInt(row, "id");
            this.Location = this.locDB.GetById(SqlFormat.ToInt(row, "location"));
            this.Replaced = SqlFormat.ToDateTime(row, "replaced");
            this.Booking = this.booDB.GetById(SqlFormat.ToGuid(row, "booking"));
            this.Booked = Booking == null ? false : true;
        }
        public Response<Battery> Create()
        {
            return this.batDB.Create(this);
        }
        public Response<Battery> Update()
        {
            return this.batDB.Update(this);
        }
        public Response<Battery> Delete()
        {
            return this.batDB.Delete(this);
        }
        public Response<Battery> Book(Guid bookingId)
        {
            if (this.Booking == null)
            {
                this.Booking = new Booking();
            }
            this.Booking.Id = bookingId;
            return this.batDB.Update(this);
        }
        public Response<Battery> Release()
        {

            //SqlData data = new SqlData();
            //data.Set("replaced", SqlSystemValue.SqlDefault);
            //data.Set("booking", SqlSystemValue.SqlNull);
            this.Booking = null;
            this.Replaced = DateTime.Now;
            return this.batDB.Update(this);
        }
    }

    public class BatteryDB : SqlHandler<Battery>
    {
        public Battery GetById(int id)
        {
            return this.GetAll().FirstOrDefault(x => x.Id == id);
        }
        public List<Battery> GetByLocationId(int id)
        {
            return this.GetAll().Where(x => x.Location.Id == id).ToList();
        }
        public List<Battery> GetByBookingId(Guid bookingId)
        {
            return this.GetAll().Where(x => x.Booking.Id.Equals(bookingId)).ToList();
        }
        public Battery GetByLocationBooking(int locationID,Guid bookingId)
        {
            return this.GetAll().FirstOrDefault(x => x.Booking.Id.Equals(bookingId) && x.Location.Id == locationID);
        }

        enum Input
        {
            NullObject,
            LocationIsNull,
            IsBooked
        }
        private bool InputIsValid(Battery b, params Input[] input)
        {
            bool result = true;
            this.Response = new Response<Battery>();
            if (b==null)
            {
                this.Response.AddMessage(ResponseMessage.NullObject);
                result = false;
            }
            else
            {
                foreach (Input i in input)
                {
                    switch (i)
                    {
                        case Input.LocationIsNull:
                            if (b.Location == null)
                            {
                                this.Response.AddMessage(ResponseMessage.NullObject,
                                    "Location is not defined");
                                result = false;
                            }

                            break;
                        case Input.IsBooked:
                            Battery toCheck = this.GetById(b.Id);
                            if (toCheck.Booked)
                            {
                                this.Response.AddMessage(ResponseMessage.DataInvalid,
                                    "Battery is booked. Make sure no booking is affected by the action.");
                                result = false;
                            }
                            break;
                    }
                }
            }
            return result;
        }
        public Response<Battery> Create(Battery b)
        {
            if (this.InputIsValid(b,Input.NullObject,Input.LocationIsNull))
            {
                SqlData data = new SqlData();
                data.Set("location", b.Location.Id);
                data.Set("replaced", SqlSystemValue.SqlDefault);
                data.Set("booking", SqlSystemValue.SqlNull);
                b.Id = this.InsertScopeId(data);

                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.CreateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.CreateHandlerError);
                }
            }
            this.Response.Item = b;
            return this.Response;
        }
        public Response<Battery> Delete(Battery b)
        {
            if (this.InputIsValid(b,Input.NullObject,Input.IsBooked))
            {
                int rowCount = this.Delete(b.Id);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.DeleteSuccess, rowCount.ToString());
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.DeleteHandlerError);
                }
            }
            this.Response.Item = b; //return item with response
            return this.Response;   //return response
        }
        public Response<Battery> Update(Battery b)
        {
            if (this.InputIsValid(b,Input.NullObject))
            {
                SqlData data = new SqlData();
                if (b.Location != null) //if location set, attempt to update it
                {
                    //make sure location exists
                    LocationDB locDB = new LocationDB();
                    if (locDB.GetById(b.Location.Id) != null)
                    {
                        data.Set("location", b.Location.Id);
                    }
                }
                if (b.Replaced != null)//if replaced time set, update it
                {
                    data.Set("replaced", b.Replaced);
                }
                data.Set("booking", b.Booking == null ? Guid.Empty : b.Booking.Id);
                this.Update(data, b.Id);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.UpdateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.UpdateHandlerError);
                }
            }
            this.Response.Item = b; // return updated object with response
            return this.Response; // return response  
        }
        public Response<Battery> BookBatch(List<Battery> toBook,Guid bookingId)
        {
            List<SqlData> batch = new List<SqlData>();
            bool batchIsValid = true; //make sure all batteries are not null
            foreach (Battery bat in toBook)
            {
                if (this.InputIsValid(bat,Input.NullObject)&&batchIsValid)
                {
                    SqlData data = new SqlData();
                    data.Set("booking", bookingId.ToString());
                    data.WhereClause = String.Format("id = {0} AND booking IS NULL", bat.Id);
                    batch.Add(data);
                }
                else
                {
                    batchIsValid = false;
                }
            }
            if (batchIsValid)
            {
                this.UpdateBatch(batch);
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.UpdateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.HandlerError);
                }
            }
            return this.Response;
        }
        public Response<Battery> CreateBatch(int locationId, int count)
        {
            List<SqlData> batch = new List<SqlData>();
            for (int i = 0; i < count; i++)
            {
                SqlData data = new SqlData();
                data.Set("location", locationId);
                data.Set("replaced", SqlSystemValue.SqlDefault);
                data.Set("booking", SqlSystemValue.SqlNull);
                batch.Add(data);
            }
            if (batch.Count>0)
            {
                this.InsertBatch(batch);
                this.Response = new Response<Battery>();
                if (this.Success)
                {
                    this.Response.AddMessage(ResponseMessage.CreateSuccess);
                }
                else
                {
                    this.Response.AddMessage(ResponseMessage.CreateHandlerError);
                }   
            }
            return this.Response;
        }
    }
    
}
