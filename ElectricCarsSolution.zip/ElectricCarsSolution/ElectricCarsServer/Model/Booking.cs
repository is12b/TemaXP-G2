﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using ElectricCars.Database;

namespace ElectricCars.Model
{
    [DataContract]
    public class Booking:SqlModel
    {
        private BatteryDB batDB;
        private BookingDB booDB;
        private List<Battery> batteries;

        [DataMember]
        public Guid Id { get; set; }
        public DateTime Created { get; set; }

        public List<Battery> Batteries {
            get
            {
                //List<Battery> batteries = new List<Battery>();
                if (this.batteries == null && this.Id != null)
                {
                    this.batteries = batDB.GetByBookingId(this.Id);
                }
                return this.batteries;
            }
            set
            {
                this.batteries = value;
            }
        }

        public Booking()
        {
            this.batDB = new BatteryDB();
            this.booDB = new BookingDB();
        }
        public void BuildObject(DataRow row)
        {
            this.Id = SqlFormat.ToGuid(row, "id");
            this.Created = SqlFormat.ToDateTime(row, "created");
        }
        public Response<Booking> Create()
        {
            return this.booDB.Create(this);
        }
        public Response<Booking> Delete()
        {
            return this.booDB.Delete(this);
        }
        public Response<Battery> Book()
        {
            return this.batDB.BookBatch(this.Batteries, this.Id);
        }

    }
    public class BookingDB : SqlHandler<Booking>
    {
        enum Input
        {
            NullObject
        }
        private bool InputIsValid(Booking b, params Input[] input)
        {
            bool result = true;
            this.Response = new Response<Booking>();
            if (b==null)
            {
                this.Response.AddMessage(ResponseMessage.NullObject);
                result = false;
            }
            return result;
        }
        public Booking GetById(Guid id)
        {
            return this.GetAll().FirstOrDefault(x => x.Id.Equals(id));
        }
        private List<Booking> GetOld(TimeSpan maxBooking)
        {
            return this.GetAll().Where(x => x.Created + maxBooking < DateTime.Now).ToList();
        }

        public Response<Booking> Create(Booking b)
        {
            this.Response = new Response<Booking>();

            string guidCol = "id";
            SqlData data = new SqlData();
            // all data is defualt, no checks needed
            data.Set("id", SqlSystemValue.SqlDefault);
            data.Set("created", SqlSystemValue.SqlDefault);

            b.Id = this.InsertScalarGuid(data, guidCol);

            // on our side everything is alright
            // make sure handler has not been naughty
            if (this.Success)
            {
                // just to be completely safe
                // who knows where the nasty digital gnomes can get their fingers to
                if (b.Id != null && b.Id!=Guid.Empty)
                {
                    this.Response.AddMessage(ResponseMessage.CreateSuccess);
                }
                else
                {
                    //something is totally wrong
                    this.Response.AddMessage(ResponseMessage.CreateUnknown);
                }
            }
            else
            {
                //something is totally wrong
                this.Response.AddMessage(ResponseMessage.CreateHandlerError);
            }
            this.Response.Item = b;
            return this.Response;
        }
        public Response<Booking> Delete(Booking b)
        {
            if (this.InputIsValid(b,Input.NullObject))
            {
                //remember that were are deling with guid as identification
                string where = String.Format("id = '{0}'", b.Id.ToString());
                int rowCount = this.Delete(where);
                if (this.Success)
                {
                    //this.Response.Success = true;
                    //this.Response.Messages.Add(String.Format("Booking is successfully deleted. {0} rows affected.",rowCount));
                    this.Response.AddMessage(ResponseMessage.DeleteSuccess,rowCount.ToString());
                }
                else
                {
                    //this.Response.Messages.Add("Could not delete booking. Database handler error.");
                    this.Response.AddMessage(ResponseMessage.DeleteHandlerError);
                }
            }
            this.Response.Item = b; //return deleted object with response
            return this.Response;   //return response

        }
        public void RemoveOld(TimeSpan maxBooking)
        {
            //try avoiding unnessesary connections to database
            // if there is cash, check expired bookings on cash
            if (this.GetOld(maxBooking).Count>0)
            {
                this.Delete(String.Format("created < DATEADD(hour, -{0}, GETDATE())", maxBooking.Hours));
            }
        }
    }
}
