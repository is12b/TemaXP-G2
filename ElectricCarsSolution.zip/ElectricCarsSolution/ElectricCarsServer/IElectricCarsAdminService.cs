﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;


namespace ElectricCarsServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IElectricCarsAdminService
    {
         /********************
         *      Shared
         ********************/
        [OperationContract]
        List<Location> GetLocations();

        /********************
         *      Admin
         ********************/
        [OperationContract]
        void CreateLink(Link l);
        
        [OperationContract]
        void AddLocation(Location l, List<Link> links, int batteriesCount);

        [OperationContract]
        void UpdateLocation(Location l);

        [OperationContract]
        void DeleteLocation(Location l);

        [OperationContract]
        void UpdateLink(Link l);

        [OperationContract]
        void DeleteLink(Link l);

        [OperationContract]
        List<Link> GetLinks();

        [OperationContract]
        List<Link> GetLinksByLocation(int locationId);
    }
}
