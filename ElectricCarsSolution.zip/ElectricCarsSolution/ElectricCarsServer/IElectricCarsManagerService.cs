﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;


namespace ElectricCarsServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IElectricCarsManagerService
    {

        /********************
         *      Manager
         ********************/
        [OperationContract]
        bool LogIn(int id, string access);

        [OperationContract]
        bool ChangeBattery(int id);

        [OperationContract]
        List<Battery> GetBatteries();
    }
}
