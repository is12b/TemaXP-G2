﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;

namespace ElectricCarsServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IElectricCarsService
    {
        /********************
         *       Test
         ********************/
        [OperationContract]
        string Test(int value);

        //[OperationContract]
        //TestModel TestComposite();

        //[OperationContract]
        //List<TestModel> TestList();

        [OperationContract]
        void TestZip();

        [OperationContract]
        void TestLocation();

        [OperationContract]
        void TestBattery();

        [OperationContract]
        void TestLink();

        [OperationContract]
        void TestBook();

        [OperationContract]
        void TestCRUD();

        [OperationContract]
        void TestUser();

        [OperationContract]
        void TestManager();

        [OperationContract]
        void TestAdmin();

        /********************
         *      Shared
         ********************/
        [OperationContract]
        List<Location> GetLocations();
        
        /********************
         *     Customer
         ********************/
        [OperationContract]
        Path GetPath(int start, int end);

        [OperationContract]
        string BookBatteries();

        void CancelBooking();
        
        /********************
         *      Manager
         ********************/
        [OperationContract]
        bool ChangeBattery(int id);

        //[OperationContract]
        //bool ChangeBattery(string bookingId, int stationId);

        [OperationContract]
        List<Battery> GetBatteries(int stationId);

        /********************
         *      Admin
         ********************/

        [OperationContract]
        int AddLocation(string name, decimal longitude, decimal latitude, string address, int zip, string city, int batteries);

        [OperationContract]
        void UpdateLocation(string name, decimal longitude, decimal latitude, string address, int zip, string city, int id);

        [OperationContract]
        bool DeleteLocation(int id);

        [OperationContract]
        void CreateLink(int loc1, int loc2, decimal km, int hr, int min);

        [OperationContract]
        void UpdateLink(int loc1, int loc2, decimal km, int hr, int min);

        [OperationContract]
        void DeleteLink(int loc1, int loc2);
    }
}
