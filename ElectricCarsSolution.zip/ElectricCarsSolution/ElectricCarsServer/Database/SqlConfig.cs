﻿namespace ElectricCars.Database
{
    /// <summary>
    /// Contains static data about sql server: host address, database name, username, password, 
    /// which is reffered to when connecting to database
    /// </summary>
    public static class SqlConfig
    {
        public const string Server = "ALEXANDRALAPTOP\\SQLEXPRESS";
        public const string Database = "3semProject";
        public const string Login = null;
        public const string Password = null;
    }
}
