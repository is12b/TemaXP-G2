﻿using System;
using System.Collections.Generic;
using System.Web;

namespace ElectricCars.Database
{
    public static class SqlCaching
    {
        private static List<string> CachingItems;
        public static void Add(string cacheName, object cacheObject, DateTime cacheExpire)
        {
            HttpRuntime.Cache.Add(cacheName.ToLower(), cacheObject, null, cacheExpire, System.Web.Caching.Cache.NoSlidingExpiration, System.Web.Caching.CacheItemPriority.NotRemovable, null);

            if (CachingItems == null)
                CachingItems = new List<string>();
            CachingItems.Add(cacheName.ToLower());
        }
        public static object Get(string cacheName)
        {
            return HttpRuntime.Cache.Get(cacheName.ToLower()) != null ? HttpRuntime.Cache.Get(cacheName.ToLower()) : null;
        }
        public static void Remove(string cacheName)
        {
            HttpRuntime.Cache.Remove(cacheName.ToLower());
            if (CachingItems != null)
                CachingItems.Remove(cacheName.ToLower());
        }
        public static void RemoveAll()
        {
            if (CachingItems != null && CachingItems.Count > 0)
            {
                foreach (string item in CachingItems)
                {
                    HttpRuntime.Cache.Remove(item);
                }
            }
        }
    }
}

