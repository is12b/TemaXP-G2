﻿using System;
using System.Data.SqlClient;

namespace ElectricCars.Database
{
    /// <summary>
    /// Takes sql server settings, creates connection string and declares SqlConnection
    /// </summary>
    public class SqlConnectionBuilder
    {
        private string server;
        private string database;
        private string login;
        private string password;
        //private SqlConnection sql;
        //public SqlConnection Sql
        //{
        //    get { return this.sql;}
        //    set {/* this.sql = new SqlConnection(this.BuildConnectionString()); */}
        //}
        public SqlConnection Sql { get; set; }
        public SqlConnectionBuilder(string server, string database, string login, string password)
        {
            this.server = server;
            this.database = database;
            this.login = login;
            this.password = password;
            this.Sql = new SqlConnection(this.BuildConnectionString());
        }

        private string BuildConnectionString()
        {
            string s1 = String.Format("Data Source={0};Initial Catalog={1};",this.server, this.database);
            string s2 = "Integrated Security=True";
            if (this.login!=null && this.password!=null)
            {
                s2 = String.Format("User ID={0};Password={1}",this.login, this.password);
            }
            string result =  String.Format("{0}{1}", s1, s2);
            return result;
        }

        public bool CheckConnection()
        {
            using (this.Sql)
            {
                try
                {
                    this.Sql.Open();
                    return true;
                }
                catch (SqlException)
                {
                    return false;
                }
                finally
                {
                    // not really necessary
                    this.Sql.Close();
                }
            }
        }
    }

}
