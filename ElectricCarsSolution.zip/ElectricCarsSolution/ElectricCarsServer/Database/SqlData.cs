﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ElectricCars.Database
{
    public class SqlSystemValue : EnumBaseType<SqlSystemValue>
    {
        public static readonly SqlSystemValue SqlDefault = new SqlSystemValue(1, "default");
        public static readonly SqlSystemValue SqlNull = new SqlSystemValue(2, "NULL");
//        public static readonly SqlSystemValue SqlGetDate = new SqlSystemValue(3, "GETDATE()");

        public SqlSystemValue(int key, string name)
            : base(key, name)
        {
        }
    }
    public class SqlData : Dictionary<string, object>
    {
        public string WhereClause { get; set; }
        //public KeyValuePair<string,object> Pair { get; set; }

        public string[] Columns { get { return this.Keys.ToArray(); } }
        public object[] Data { get { return this.Values.ToArray(); } }

        public void Set(string column, object data)
        {
            this[column] = data;
        }
        public void Where(string clause)
        {
            this.WhereClause = "";
        }
        public string SqlValues()
        {
            string result = "";

            foreach (KeyValuePair<string, object> pair in this)
            {
                string separator = result == "" ? "" : ", ";
                result = String.Format("{0}{1}{2}", result, separator, this.Parse(pair.Value));
            }
            return result;
        }

        public string SqlColumns()
        {
            string result = "";
            foreach (KeyValuePair<string, object> pair in this)
            {
                string separator = result == "" ? "" : ", ";
                result = String.Format("{0}{1}{2}", result, separator, pair.Key);
            }
            return result;
        }

        public string SqlPairs()
        {
            string result = "";
            foreach (KeyValuePair<string, object> pair in this)
            {
                string separator = result == "" ? "" : ", ";
                result = String.Format("{0}{1}{2}={3}", result, separator, pair.Key, this.Parse(pair.Value));
            }
            return result;
        }

        private string Parse(object o)
        {
            string result = "";

            if (o == null)
            {
                result = "default";
            }
            else
            {
                if (o.GetType() == typeof(int))
                {
                    result = String.Format("{0}", o.ToString());
                }
                else if (o.GetType() == typeof(SqlSystemValue))
                {
                    SqlSystemValue s = (SqlSystemValue)o;
                    result = String.Format("{0}", s.Name);
                }
                else if (o.GetType() == typeof(decimal))
                {
                    result = String.Format("'{0}'", o.ToString().Replace(",", "."));
                }
                else if (o.GetType() == typeof(Guid))
                {
                    Guid g = (Guid)o;
                    if (!g.Equals(Guid.Empty))
                    {
                        result = String.Format("'{0}'", o.ToString().Replace(",", "."));
                    }
                    else
                    {
                        result = "NULL";
                    }
                }
                else
                {
                    result = String.Format("'{0}'", o.ToString());
                }
            }

            return result;
        }
    }
}
