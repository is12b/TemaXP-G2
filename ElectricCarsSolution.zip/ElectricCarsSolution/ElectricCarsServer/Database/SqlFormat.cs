﻿using System;
using System.Data;

namespace ElectricCars.Database
{
    public static class SqlFormat
    {
        #region Data Formating
        public static string ToString(DataRow dr, string fieldName)
        {
            return dr[fieldName] != null ? dr[fieldName].ToString() : string.Empty;
        }
        public static DateTime ToDateTime(DataRow dr, string fieldName)
        {
            return dr[fieldName] != DBNull.Value ? (DateTime)dr[fieldName] : DateTime.MinValue;
        }
        public static TimeSpan ToTimeSpan(DataRow dr, string fieldName)
        {
            return dr[fieldName] != DBNull.Value ? (TimeSpan)dr[fieldName] : TimeSpan.MinValue;
        }
        public static int ToInt(DataRow dr, string fieldName)
        {
            return dr[fieldName] != DBNull.Value ? (int)dr[fieldName] : 0;
        }
        public static decimal ToDecimal(DataRow dr, string fieldName)
        {
            return dr[fieldName] != null ? (decimal)dr[fieldName] : 0;
        }
        public static Guid ToGuid(DataRow dr, string fieldName)
        {
            Guid value = Guid.Empty;
            if (dr[fieldName] != DBNull.Value && dr[fieldName] != null)
            {
                value = (Guid)dr[fieldName];
            }
            return value;
        }
        public static bool ToBool(DataRow dr, string fieldName)
        {
            return dr[fieldName] != DBNull.Value ? (bool)dr[fieldName] : false;
        }

        #endregion
    }
}
