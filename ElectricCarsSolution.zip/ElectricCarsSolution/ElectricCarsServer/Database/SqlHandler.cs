﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using ElectricCars.Handlers;

namespace ElectricCars.Database
{

    abstract public class SqlHandler<T> where T : SqlModel, new()
    {
        private SqlConnectionBuilder con;
        private string table;

        protected bool Success { get; set; }
        protected Response<T> Response;


        public SqlHandler()
        {
            //this.con = new SqlConnectionBuilder(SqlConfig.Server, SqlConfig.Database, SqlConfig.Login, SqlConfig.Password);
            //this.con = new SqlConnectionBuilder(Config.SqlServer, Config.SqlDatabase, Config.SqlUser, Config.SqlPassword);
            this.table = typeof(T).Name;
        }

        private void BuildConnection()
        {
            this.con = new SqlConnectionBuilder(Config.SqlServer, Config.SqlDatabase, Config.SqlUser, Config.SqlPassword);
        }

        public T BuildObject(DataRow row)
        {
            T item = new T();
            item.BuildObject(row);
            return item;
        }
        private void AddResponse(string message)
        {
            if (this.Response == null)
            {
                this.Response = new Response<T>();
            }
            this.Response.AddMessage(ResponseMessage.SqlException,message);
        }

        #region *** Delete Methods***

        /// <summary>
        /// Deletes row from table where column 'id' equals given id. Returns affected rows count.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Returns affected rows count</returns>
        protected int Delete(int id)
        {
            return this.Delete(id,"id");
        }
        /// <summary>
        /// Deletes row from table where given idColumn equals given (int) id.Returns affected rows count.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="idColumn"></param>
        /// <returns>Returns affected rows count</returns>
        protected int Delete(int id, string idColumn)
        {
            string where = String.Format("{0} = {1}", idColumn, id);
            return this.Delete(where);
        }
        /// <summary>
        /// Deletes row from table where given idColumn equals given (string) id. Returns affected rows count.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="idColumn"></param>
        /// <returns>Returns affected rows count</returns>
        protected int Delete(string id, string idColumn)
        {
            string where = String.Format("{0} = '{1}'", idColumn, id);
            return this.Delete(where);
        }
        /// <summary>
        /// Deletes row from table on given 'where' clause. Returns affected rows count.
        /// </summary>
        /// <param name="where"></param>
        /// <returns>Returns affected rows count</returns>
        protected int Delete(string where)
        {
            string query = String.Format("DELETE from {0} WHERE {1}; SELECT @@ROWCOUNT;", this.table, where);
            return this.DeleteHandler(query);
        }

        private int DeleteHandler(string query)
        {
            this.BuildConnection();
            int scalar = 0;
            this.Success = false;


            using (this.con.Sql)
            {
                System.Data.SqlClient.SqlCommand command = this.con.Sql.CreateCommand();
                command.CommandText = query;
                try
                {
                    this.con.Sql.Open();
                    try
                    {
                        scalar = Convert.ToInt32(command.ExecuteScalar());
                        if (scalar > 0)
                        {
                            SqlCaching.Remove(this.table);
                        }
                    }
                    catch (Exception e)
                    {
                        this.AddResponse(e.Message);
                        //Console.WriteLine(e.StackTrace);
                    }
                }
                catch (SqlException e)
                {
                    this.AddResponse(e.Message);
                    //Console.WriteLine(e.StackTrace);

                }
                //this._con.Sql.Open();
                //scalar = Convert.ToInt32(command.ExecuteScalar());
                //if (scalar > 0)
                //{
                //    SqlCaching.Remove(this._table);
                //}
            }
            return scalar;
        }
        #endregion

        #region *** Update Methods ***
        private string UpdateQuery(SqlData data)
        {
            return String.Format(@" 
                BEGIN TRY 
                     UPDATE {0} SET {1} WHERE {2}
	                 IF @@ROWCOUNT = 0   
                     BEGIN  RAISERROR(-904, 10, 07) WITH LOG
                     END
                END TRY 
                BEGIN CATCH  
	                THROW 60000,'Row with {2} was not updated and I dont know why.', 1;
                END CATCH;",
                this.table, data.SqlPairs(), data.WhereClause
                );
        }
        /// <summary>
        /// Update table with given data where column 'id' equals given id
        /// </summary>
        /// <param name="data"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        protected void Update(SqlData data, int id)
        {
            data.WhereClause = String.Format("{0} = {1}", "id", id);
            this.Update(data);
        }
        /// <summary>
        /// Updates table with given data on given 'where' clause in sql data
        /// </summary>
        /// <param name="data"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        protected void Update(SqlData data)
        {
            string query = this.UpdateQuery(data);
            UpdateHandler(query);
        }
        /// <summary>
        /// Update table with multiple data on given 'where' clause
        /// </summary>
        /// <param name="batch"></param>
        /// <param name="where"></param>
        /// <returns></returns>
        protected void UpdateBatch(List<SqlData> batch)
        {
            string query = "";
            foreach (SqlData data in batch)
            {
                query = String.Format("{0} {1}", query,this.UpdateQuery(data));
            }
            UpdateHandler(query);
        }
        private void UpdateHandler(string query)
        {
            this.BuildConnection();
            this.Success = false;
            //bool result = false;

            using (this.con.Sql)
            {
                this.con.Sql.Open();
                System.Data.SqlClient.SqlCommand command = this.con.Sql.CreateCommand();
                System.Data.SqlClient.SqlTransaction transaction;

                // Start a local transaction.
                transaction = this.con.Sql.BeginTransaction();

                // Must assign both transaction object and connection 
                // to Command object for a pending local transaction
                command.Connection = this.con.Sql;
                command.Transaction = transaction;

                try
                {
                    command.CommandText = query;
                    command.ExecuteNonQuery();

                    // Attempt to commit the transaction.
                    transaction.Commit();
                    Console.WriteLine("Updated");
                    SqlCaching.Remove(this.table);
                    this.Success = true;
                }
                catch (Exception commitEx)
                {
                    string exceptionType = String.Format("Commit Exception Type: {0}", commitEx.GetType());
                    string exceptionMessage = String.Format("Message: {0}", commitEx.Message);

                    this.AddResponse(commitEx.Message);

                    Console.WriteLine("Commit Exception Type: {0}", commitEx.GetType());
                    Console.WriteLine("Message: {0}", commitEx.Message);
                    Console.WriteLine(commitEx.StackTrace);
                    

                    // Attempt to roll back the transaction. 
                    try
                    {
                        transaction.Rollback();
                    }
                    catch (Exception rollbackEx)
                    {
                        // This catch block will handle any errors that may have occurred 
                        // on the server that would cause the rollback to fail, such as 
                        // a closed connection.
                        this.AddResponse(rollbackEx.Message);
                        Console.WriteLine("Rollback Exception Type: {0}", rollbackEx.GetType());
                        Console.WriteLine("Message: {0}", rollbackEx.Message);
                        Console.WriteLine(rollbackEx.StackTrace);
                    }
                }
            }
            //return result;
        }
        #endregion

        #region *** Insert Methods ***
        private string InsertQuery(SqlData data)
        {
            return String.Format(
                "INSERT into {0} ({1}) VALUES ({2}); SELECT @@ROWCOUNT;",
                this.table,
                data.SqlColumns(),
                data.SqlValues()
                );
        }
        protected int Insert(SqlData data)
        {
            string query = this.InsertQuery(data);
            return Convert.ToInt32(InsertHandler(query));
        }
        protected void InsertBatch(List<SqlData> batch)
        {
            string query = "";
            foreach (SqlData data in batch)
            {
                query = String.Format("{0} {1}", query, this.InsertQuery(data));
            }
            this.InsertHandler(query);
        }
        protected int InsertScopeId(SqlData data)
        {
            string query = String.Format(
                "INSERT into {0} ({1}) VALUES ({2}); SELECT SCOPE_IDENTITY();",
                this.table,
                data.SqlColumns(),
                data.SqlValues()
                );
            return Convert.ToInt32(InsertHandler(query));
        }
        protected Guid InsertScalarGuid(SqlData data, string scalarColumn)
        {
            string query = String.Format(
                "INSERT into {0} ({1}) OUTPUT INSERTED.{3} VALUES ({2});"
                ,this.table, data.SqlColumns(),data.SqlValues(),scalarColumn);
            return new Guid(this.InsertHandler(query).ToString());
        }
        private object InsertHandler(string query)
        {
            this.BuildConnection();
            object scalar = null;
            this.Success = false;

            using(this.con.Sql)
            {
                System.Data.SqlClient.SqlCommand command = this.con.Sql.CreateCommand();
                command.CommandText = query;
                try
                {
                    this.con.Sql.Open();
                    try
                    {
                        scalar = command.ExecuteScalar();
                        this.Success = true;
                        SqlCaching.Remove(this.table);
                    }
                    catch (Exception e)
                    {
                        this.AddResponse(e.Message);
                        Console.WriteLine(e.StackTrace);
                    }
                }
                catch (SqlException e)
                {
                    this.AddResponse(e.Message);
                    Console.WriteLine(e.StackTrace);
                }
            }
            return scalar;
        }
        #endregion

        #region *** Read Methods ***
        private string SelectQuery()
        {
            return String.Format("select * from {0}", this.table);
        }
        public List<T> GetAll()
        {
            this.BuildConnection();
            List<T> result;
            var cashing = SqlCaching.Get(this.table);
            if (SqlCaching.Get(this.table) == null)
            {
                result = new List<T>();
                try
                {
                    var ds = new DataSet();
                    using (this.con.Sql)
                    {
                        this.con.Sql.Open();
                        var command = new SqlCommand(SelectQuery(), this.con.Sql);
                        var adapter = new SqlDataAdapter(command);
                        adapter.Fill(ds, this.table);

                    }
                    foreach (DataRow dr in ds.Tables[this.table].Rows)
                    {
                        result.Add(this.BuildObject(dr));
                    }
                    SqlCaching.Add(this.table, result, DateTime.Now.AddDays(2));
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
            else
            {
                result = (List<T>)SqlCaching.Get(this.table);
            }
            return result;
        }
        #endregion
    }
}
