﻿using System.Data;

namespace ElectricCars.Database
{
    public interface SqlModel
    {
        void BuildObject(DataRow row);
//        void Create();
//        void Update();
//        void Delete();
    }
}
