﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricCars.Database
{
    public enum ResponseMessage
    {
        //shared 
        NullObject = 100,
        Unknown = 101,
        HandlerError = 102,

        //Data check
        DataEmpty = 201,
        DataInvalid = 202,

        //create
        CreateSuccess = 301,
        CreateHandlerError = 302,
        CreateUnknown = 303,

        //delete
        DeleteSuccess = 401,
        DeleteHandlerError = 402,
        DeleteUnknown = 403,

        //update
        UpdateSuccess = 501,
        UpdateHandlerError = 502,
        UpdateUnknown = 503,

        //exception
        SqlException = 600

    }
    public class Response<T> where T : SqlModel
    {
        public T Item { get; set; }
        public bool Success { get; set; }
        public List<string> Messages { get; set; }

        public Response()
        {
            this.Success = false;
            this.Messages = new List<string>();
        }
        /// <summary>
        /// Adds message to Messages collection.
        /// Message.DataEmpty format: [empty_field];
        /// Message.DataInvalid format: [invalid_exception];
        /// Meddage.DeleteSuccess format: [rows_affected];
        /// </summary>
        /// <param name="m"></param>
        /// <param name="info"></param>
        public void AddMessage(ResponseMessage m, string info="")
        {
            string message = "";
            string name = typeof(T).Name;
            string details = info==""?"":String.Format(" {0}",info);
            string exception = info == "" ? "" : String.Format(" Sql exception: {0}", info);
            string count = info == "" ? "" : String.Format(" {0} rows affected.",info);
            switch (m)
            {
                case ResponseMessage.NullObject:
                    message = String.Format(" The object is null.{0}", details);
                    break;
                case ResponseMessage.Unknown:
                    message = String.Format("Something went totally wrong. FSB may know.");
                    break;
                case ResponseMessage.HandlerError:
                    break;
                case ResponseMessage.DataEmpty:
                    message = String.Format("Empty data error. Field {0} cannot be empty.",info);
                    break;
                case ResponseMessage.DataInvalid:
                    message = String.Format("{1} data is invalid.{0}",details, name);
                    break;
                case ResponseMessage.CreateSuccess:
                    message = String.Format("{0} was successfully created.",name);
                    this.Success = true;
                    break;
                case ResponseMessage.CreateHandlerError:
                    message = String.Format("{0} was not created. Database handler error.", name);
                    break;
                case ResponseMessage.CreateUnknown:
                    message = String.Format("Could not create {0}. Something went totally wrong. FSB may know.", name.ToLower());
                    break;
                case ResponseMessage.UpdateSuccess:
                    message = String.Format("{0} was successfully updated.", name);
                    this.Success = true;
                    break;
                case ResponseMessage.UpdateHandlerError:
                    message = String.Format("{0} was not updated. Database handler error.", name);
                    break;
                case ResponseMessage.UpdateUnknown:
                    message = String.Format("Could not update {0}. Something went totally wrong. FSB may know.", name.ToLower());
                    break;
                case ResponseMessage.DeleteSuccess:
                    message = String.Format("{0} was successfully deleted.{1}", name, count);
                    this.Success = true;
                    break;
                case ResponseMessage.DeleteHandlerError:
                    message = String.Format("{0} was could not be deleted. Database handler error.", name);
                    break;
                //case Message.DeleteSqlException:
                //    message = String.Format("{0} could not be deleted.{1}", name, exception);
                //    break;
                case ResponseMessage.DeleteUnknown:
                    message = String.Format("Could not delete {0}. Something went totally wrong. FSB may know.", name.ToLower());
                    break;
                case ResponseMessage.SqlException:
                    message = String.Format("Sql operation for {0} could not be proceed.{1}", name, exception);
                    break;
                default:
                    break;
            }
            this.Messages.Add(message);
        }
    }
}
