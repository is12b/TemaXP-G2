﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;
using ElectricCars.Handlers;
using ElectricCars.Database;

namespace ElectricCarsServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class ElectricCarsUserService:IElectricCarsUserService
    {
        #region *** Properties ***
        //private TimeSpan batteryCharge = new TimeSpan(10, 0, 0);
        //private decimal batteryLife = 150;
        //private TimeSpan maxBooking = new TimeSpan(24, 0, 0);
        private TimeSpan batteryCharge = Config.BatteryCharge;
        private decimal batteryLife = Config.BatteryLife;
        private TimeSpan maxBooking = Config.MaxBooking;

        private Path path;
        private Booking booking;
        #endregion

        #region *** Constructors ***
        public ElectricCarsUserService()
        {
            BookingDB booDB = new BookingDB();
            //string s = booDB.con.Sql.ConnectionString;
            //Console.WriteLine("Ready!");
            //Console.WriteLine("String:{0}",s);
            booDB.RemoveOld(this.maxBooking);
        }
        #endregion

        #region *** User ***
        public List<Location> GetLocations()
        {
            LocationDB lDB = new LocationDB();
            return lDB.GetAll();
        }
        public Path GetPath(int start, int end)
        {
            Pathfinder pf = new Pathfinder();
            this.path = pf.ShortestPath(start, end);
            return path;
        }
        public string BookBatteries()
        {
            string bookingCode = "";
            //if booking doesnt exist create new
            if (this.booking == null)
            {
                this.booking = new Booking();
                this.booking.Create();
            }
            // just make sure that book batteries was called after path was found
            if (this.path != null)
            {
                //book the batteries
                //List<Battery> batteries = p.Batteries;
                this.booking.Batteries = path.Batteries;
                //bool success = this.booking.Book();
                Response<Battery> r = this.booking.Book();
                if (r.Success)
                {
                    // if booking successfull 
                    // 1) nulify path
                    this.path = null;

                    // 2) clear booking
                    bookingCode = this.booking.Id.ToString();
                    this.booking = null;
                }
            }
            return bookingCode;
        }
        public void CancelBooking()
        {
            if (this.booking != null) //if booking was created
            {
                this.booking = null; // nulify booking
                this.booking.Delete(); // remove from database
            }
        }
        #endregion
    }
}
