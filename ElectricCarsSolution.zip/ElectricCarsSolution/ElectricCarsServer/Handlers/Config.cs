﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//using System.Web.Configuration;
using System.Configuration;
/// <summary>
/// Summary description for Config
/// </summary>
/// 
namespace ElectricCars.Handlers
{
    public static class Config
    {
       
        public static TimeSpan BatteryCharge 
        {
            get 
            {
                int hr = Convert.ToInt32(Get("BatteryChargeHr"));
                int min = Convert.ToInt32(Get("BatteryChargeMin"));
                int sec = Convert.ToInt32(Get("BatteryChargeSec"));
                return new TimeSpan(hr,min,sec); 
            }
            set 
            {
                TimeSpan time = value;
                Set("BatteryChargeHr", time.Hours.ToString());
                Set("BatteryChargeMin", time.Hours.ToString());
                Set("BatteryChargeSec", time.Hours.ToString());
            }
        }
        public static decimal BatteryLife
        {
            get 
            {
                return Convert.ToDecimal(Get("LifeSpan"));
            }
            set 
            { 
                Set("LifeSpan", value.ToString()); 
            }
        }
        public static TimeSpan MaxBooking
        {
            get 
            {
                int hr = Convert.ToInt32(Get("MaxBookingHr"));
                int min = Convert.ToInt32(Get("MaxBookingMin"));
                int sec = Convert.ToInt32(Get("MaxBookingSec"));
                return new TimeSpan(); 
            }
            set 
            {
                TimeSpan time = value;
                Set("MaxBookingHr", time.Hours.ToString());
                Set("MaxBookingMin", time.Hours.ToString());
                Set("MaxBookingSec", time.Hours.ToString());
            }
        }
        public static string SqlServer
        {
            get { return Get("SqlServer"); }
            set { Set("SqlServer", value); }
        }
        public static string SqlDatabase
        {
            get { return Get("SqlDatabase"); }
            set { Set("SqlDatabase", value); }
        }
        public static string SqlUser
        {
            get 
            {
                string user = Get("SqlUser");
                return user==""?null:user; 
            }
            set { Set("SqlUser", value); }
        }
        public static string SqlPassword
        {
            get 
            {
                string pass = Get("SqlPassword");
                return pass == ""?null:pass; 
            }
            set { Set("SqlPassword", value); }
        }

        private static void Set(string key, string value)
        {
            //var configuration = WebConfigurationManager.OpenWebConfiguration("~");
            //configuration.AppSettings.Settings[key].Value = value;
            //configuration.Save();
            try
            {
                var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                var settings = configFile.AppSettings.Settings;
                if (settings[key] == null)
                {
                    settings.Add(key, value);
                }
                else
                {
                    settings[key].Value = value;
                }
                configFile.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Error writing app settings");
            }
        }
        private static string Get(string key)
        {
            string result = "Not Found";
            //return WebConfigurationManager.AppSettings.Get(key);
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                result = appSettings[key];
                
                //Console.WriteLine(result);
            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Error reading app settings");
            }
            return result;
        }
    }
}