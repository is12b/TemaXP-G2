﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using ElectricCars.Model;

namespace ElectricCars.Handlers.ECPathfinder
{
    [DataContract]
    public class Path
    {
        [DataMember]
        public LinkedList<PathNode> Route { get; set; }
        [DataMember]
        public List<Location> Stations;
        [DataMember]
        public List<Battery> Batteries;

        public Path(Vertex start, Vertex end)
        {
            this.Route = new LinkedList<PathNode>();
            this.Batteries = new List<Battery>();
            this.Stations = new List<Location>();

            this.AddNode(start);
            //this.Start = start;
            //this.End = end;
        }

        private void AddNode(Vertex node)
        {
            //reformat vertex to pathnode, 
            //cuz we dont need all the information from vertex 
            //to be thrown around without any use
            PathNode n = new PathNode(node.Location, node.FreeBattery);
            // add node to end of route
            this.Route.AddLast(n);
            // if vertex has a recharge link, 
            if (node.Recharge!=null)
            {
                PathNode station = this.Route.FirstOrDefault(x => x.Location.Id == node.Recharge.Location.Id);
                // 1) mark the link as station
                station.IsStation = true;
                // 2) add location to stations list for further ui usage
                this.Stations.Add(station.Location);
                // 3) add its battery to battery list for further use in booking
                this.Batteries.Add(station.Battery);
            }
            //if this is not the end of list, do the same to its successor
            if (node.Successor!=null)
            {
                this.AddNode(node.Successor);
            }
        }
    }
    [DataContract]
    public class PathNode
    {
        [DataMember]
        public Location Location { get; set; }

        [DataMember]
        public bool IsStation { get; set; }

        [DataMember]
        public Battery Battery { get; set; }

        public PathNode(Location l, Battery b)
        {
            this.Location = l;
            this.Battery = b;
        }
    }


    public class Neighbor
    {
        public Vertex Vertex { get; set; }
        public decimal Distance { get; set; }

        public Neighbor()
        {
        }

        public Neighbor(Vertex node, decimal distance)
        {
            this.Vertex = node;
            this.Distance = distance;
        }
    }

    public class Vertex
    {
        public List<Neighbor> Neighbors { get; set; }
        public bool Visited { get; set; }
        public decimal Cost { get; set; }
        public Location Location { get; set; }
        public Vertex Predecessor { get; set; }
        public Vertex Successor { get; set; }
        public Vertex Recharge { get; set; }
        public Battery FreeBattery { get; set; }

        public Vertex(Location location)
        {
            this.Location = location;
            this.Visited = false;
            this.Neighbors = new List<Neighbor>();
            this.Cost = Decimal.MaxValue;
        }
        
        public bool HasBatteries()
        {
            List<Battery> freeBatteries = this.Location.FreeBatteries();
            bool result = false;
            if(freeBatteries.Count>0)
            {
                this.FreeBattery = freeBatteries.FirstOrDefault();
                result = true;
            }
            return result;
        }
    }
    public class Pathfinder
    {
        /********************
         * Properties
         *******************/
        //private decimal maxBatteryLife; //km
        //private TimeSpan maxBatteryCharge; 

        private LinkDB _links;
        private LocationDB _locations;
        
        private List<Vertex> graph;

        private Vertex end;
        private Vertex start;

        //public Vertex Start { get { return this._start; } set { } }
        //public Vertex End { get { return this._end; } set { } }
        
        

        /*******************
         * constructor
         *******************/
        public Pathfinder()
        {
            this._links = new LinkDB();
            this._locations = new LocationDB();
            //this.maxBatteryLife = batteryLife;
            //this.maxBatteryCharge = batteryCharge;//new TimeSpan(batteryCharge,0,0);
        }

        /*******************
        * methods
        *******************/
        /// <summary>
        /// Finds path between start and end points 
        /// </summary> 
        public Path ShortestPath(int startId, int endId)
        {
            this.BuildGraph(); // have a clean graph, dont wanna have old data messing with us
            this.start = FindVertex(startId);
            this.end = FindVertex(endId);
            this.start.Cost = 0; 
            //this._start.BatteryLife = this._batteryLife; //start with full battery
            Process(this.start);
            this.AddSuccessor(this.end);
            Path path = null;
            if (this.end.Predecessor!=null)
            {
                path = new Path(this.start,this.end);
            }
            return path;
        }

        /// <summary>
        /// Builds graph from locations collection  
        /// </summary> 
        private void BuildGraph()
        {
            this.graph = new List<Vertex>();
            //this._lpath = new List<Location>();
            // for each location create vortex in graph
            foreach (Location location in this._locations.GetAll())
            {
                Vertex v = new Vertex(location);
                this.graph.Add(v);
            }

            //// fill links to verteces 
            foreach (Link link in this._links.GetAll())
            {
                Vertex v1 = this.FindVertex(link.Location1.Id);
                Vertex v2 = this.FindVertex(link.Location2.Id);
                v1.Neighbors.Add(new Neighbor(v2, link.Distance));
                v2.Neighbors.Add(new Neighbor(v1, link.Distance));
            }
        }
        
        /// <summary>
        /// Processes Dijkstra on given vertex
        /// </summary> 
        private void Process(Vertex node)
        {
            if (!node.Visited)                                      // if not visited
            {
                node.Visited = true;                                // visisted now
                // dont divide with zero
                // if cost is max value, it has no connection to start
                // no need to proceed
                if (node.Cost != Decimal.MaxValue)
                {
                    foreach (Neighbor neighbor in node.Neighbors)
                    {
                        decimal cost = node.Cost + neighbor.Distance;        // new cost is neighbour cost plus vector length
                        //dont even try if we cannot reach it anyway
                        // if its shorter path than earlier
                        if (neighbor.Distance < Config.BatteryLife/*this.maxBatteryLife*/ && cost < neighbor.Vertex.Cost)
                        {
                            // if we have enough battery to get there, continue
                            if (this.BatteryLife(node) > neighbor.Distance)
                            {
                                // nulify previous station
                                neighbor.Vertex.Recharge = null;
                                this.AddPredessesor(neighbor, node, cost);
                            }
                            //if we cant get there on this battery, try find a station to recharge
                            else
                            {
                                // if this is recharge station, problem is solved
                                if (node.HasBatteries())
                                {
                                    //node.BatteryLife = this._batteryLife;
                                    neighbor.Vertex.Recharge = node;
                                    this.AddPredessesor(neighbor, node, cost);
                                }
                                //if not,
                                else
                                {
                                    //now lets see if there is a station somewhere on the way
                                    Vertex rechargeStation = this.FindRecharge(node.Predecessor); // recharge station somewhere on the way  
                                    // make sure we can make the trip from previous station to next 
                                    if ((node.Cost - node.Predecessor.Cost) + neighbor.Distance < Config.BatteryLife /*this.maxBatteryLife*/ &&
                                        rechargeStation != null && 
                                        this.BatteryLife(node) > neighbor.Distance)
                                    {
                                        this.AddPredessesor(neighbor, node, cost);
                                    }
                                }
                            }
                        }
                    }
                    // unvisited list
                    List<Vertex> unvisited = this.graph.Where(x => x.Visited == false).ToList();
                    // next is vertex with smallest cost among unvisited
                    Vertex next = unvisited.FirstOrDefault(x => x.Cost == unvisited.Min(y => y.Cost));
                    // if there is next and its not end node, process it
                    if (next != null)
                    {
                        if (next.Location.Id != this.end.Location.Id)
                        {
                            Process(next);
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Calculate battery life
        /// </summary> 
        private decimal BatteryLife(Vertex node)
        {
            decimal batteryLife = 0;
            if (node.Recharge == null)
            {
                batteryLife = Config.BatteryLife/*this.maxBatteryLife*/ - node.Cost;
            }
            else
            {
                batteryLife = Config.BatteryLife /*this.maxBatteryLife*/-(node.Cost - node.Recharge.Cost);
            }
            return batteryLife;
        }
        /// <summary>
        /// assign the node as predessessor to its neighbor, assign the cost
        /// </summary>
        /// <param name="neighbor"></param>
        /// <param name="node"></param>
        /// <param name="cost"></param>
        private void AddPredessesor(Neighbor neighbor, Vertex node, decimal cost)
        {
            neighbor.Vertex.Cost = cost;                   // set new cost
            neighbor.Vertex.Predecessor = node;            // set new ancestor
        }
        /// <summary>
        /// Finds recharge station up the path
        /// </summary> 
        private Vertex FindRecharge(Vertex node)
        {
            Vertex station = null;
            if (node.Location.Id!=this.start.Location.Id)
            {
                
                if (node.HasBatteries())
                {
                    station = node;
                }
                else
                {
                    station = this.FindRecharge(node.Predecessor);
                    
                }   
            }
            return station;
        }
        /// <summary>
        /// Add successors
        /// </summary> 
        private void AddSuccessor(Vertex node)
        {
            if (node.Predecessor != null)
            {
                node.Predecessor.Successor = node;
                AddSuccessor(node.Predecessor);
            }
        }

        /// <summary>
        /// Returns vertex in graph with given Id
        /// </summary> 
        private Vertex FindVertex(int id)
        {
            return this.graph.FirstOrDefault(x => x.Location.Id == id);
        }
    }
}
