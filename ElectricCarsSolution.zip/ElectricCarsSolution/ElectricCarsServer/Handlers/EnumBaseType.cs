﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
public abstract class EnumBaseType<T> where T : EnumBaseType<T>
{
    protected static List<T> enumValues = new List<T>();

    public readonly int Key;
    public readonly string Name;
    public readonly object Value;

    public EnumBaseType(int key, string name)
    {
        this.Key = key;
        this.Name = name;
        enumValues.Add((T)this);
    }
    public static ReadOnlyCollection<T> GetValues()
    {
        return enumValues.AsReadOnly();
    }

    public static T GetByKey(int key)
    {
        foreach (T t in enumValues)
        {
            if (t.Key == key) return t;
        }
        return null;
    }

    public override string ToString()
    {
        return Name;
    }
}
