﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricCars.Handlers;
using ElectricCars.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ElectricCars.Handlers.ECPathfinder;
using ElectricCars.Model;

namespace ElectricCarsServer.UnitTest
{
    [TestClass]
    public class UnitTest
    {
        //private TimeSpan batteryCharge = Config.BatteryCharge;
        //private decimal batteryLife = Config.BatteryLife;
        private TimeSpan maxBooking = Config.MaxBooking;

        private Path path;
        private Booking booking;
        //[TestMethod]
        public void ConfigTest()
        {
            string Server = Config.SqlServer;
            string Database = Config.SqlDatabase;
        }
        //[TestMethod]
        public void SqlConnectionTest()
        {
            SqlConnectionBuilder c = new SqlConnectionBuilder(Config.SqlServer,Config.SqlDatabase,Config.SqlUser,Config.SqlPassword);
            c.CheckConnection();
        }
        [TestMethod]
        public void PathfinderTest()
        {
            Pathfinder pf = new Pathfinder();
            this.path = pf.ShortestPath(1064, 1115);
            //return path;
            string bookingCode = "";
            //if booking doesnt exist create new
            if (this.booking == null)
            {
                this.booking = new Booking();
                this.booking.Create();
            }
            // just make sure that book batteries was called after path was found
            if (this.path != null)
            {
                //book the batteries
                //List<Battery> batteries = p.Batteries;
                this.booking.Batteries = path.Batteries;
                //bool success = this.booking.Book();
                Response<Battery> r = this.booking.Book();
                if (r.Success)
                {
                    // if booking successfull 
                    // 1) nulify path
                    this.path = null;

                    // 2) clear booking
                    bookingCode = this.booking.Id.ToString();
                    this.booking = null;
                }
            }
        }
    }
}
