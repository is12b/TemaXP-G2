﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;



namespace ElectricCarsServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class ElectricCarsAdminService : IElectricCarsAdminService
    {
        private LocationDB locDB;
        private BatteryDB batDB;
        private LinkDB linkDB;

        public ElectricCarsAdminService()
        {
            this.locDB = new LocationDB();
            this.batDB = new BatteryDB();
            this.linkDB = new LinkDB();
        }

        #region *** Shared ***
        public List<Location> GetLocations()
        {
            LocationDB lDB = new LocationDB();
            return lDB.GetAll();
        }
        #endregion

        #region *** Admin ***
            public void AddLocation(Location l, List<Link> links, int batteriesCount)
            {
                int locationPlaceholderId = l.Id;
                l.CreateConnection();
                l.Create();
                if (l.Id > 0)
                {
                    this.batDB.CreateBatch(l.Id, batteriesCount);
                }
                /*********WARNING ***************/
                // insert batch here

                //********Exceptions warning *********//
                // links will not have location id,
                // need a check on locations not null and having 
                // id of newly incerted location
                // possible merge on links incertion with location
                // insertion. in this case can be problem with tables when
                // building query
                foreach (Link link in links)
                {
                    if (link.Location1.Id == locationPlaceholderId)
                    {
                        link.Location1 = l;
                    }
                    else if (link.Location2.Id == locationPlaceholderId)
                    {
                        link.Location2 = l;
                    }
                    link.CreateConnection();
                    link.Create();
                }
            }
            public void UpdateLocation(Location l)
            {
                l.CreateConnection();
                l.Update();
            }
            public void DeleteLocation(Location l)
            {
                l.CreateConnection();
                l.Delete();
            }
            public void CreateLink(Link l)
            {
                l.CreateConnection();
                l.Create();
            }
            public void UpdateLink(Link l)
            {
                l.CreateConnection();
                l.Update();
            }
            public void DeleteLink(Link l)
            {
                l.CreateConnection();
                l.Delete();
            }
            public List<Link> GetLinks()
            {
                return this.linkDB.GetAll();
            }
            public List<Link> GetLinksByLocation(int locationId)
            {
                return this.linkDB.GetByLocationId(locationId);
            }
        #endregion
    }
}
