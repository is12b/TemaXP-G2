﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Handlers.ECPathfinder;
using ElectricCars.Model;

namespace ElectricCarsServer
{
    [ServiceContract]
    interface IElectricCarsUserService
    {

        /********************
         *      Shared
         ********************/
        [OperationContract]
        List<Location> GetLocations();
        /********************
         *     Customer
         ********************/
        [OperationContract]
        Path GetPath(int start, int end);

        [OperationContract]
        string BookBatteries();

        [OperationContract]
        void CancelBooking();
    }
}
