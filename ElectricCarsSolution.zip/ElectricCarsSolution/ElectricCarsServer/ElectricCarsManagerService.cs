﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;
using ElectricCars.Database;

namespace ElectricCarsServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class ElectricCarsManagerService : IElectricCarsManagerService
    {

        private BatteryDB batDB;
        private int stationId;

        public bool LogIn(int id, string access)
        {
            bool result = false;
            LocationDB locDB = new LocationDB();
            locDB.GetById(id);
            if (true) // loc.Access.Equals(md5(access))
            {
                this.batDB = new BatteryDB();
                this.stationId = id;
            }
            return result;
        }
        public bool ChangeBattery(int id)
        {
            bool result = false;
            if (this.batDB!=null)
            {
                Battery b = this.batDB.GetById(id);

                Response<Battery> r =  b.Release();
                if (r.Success)
                {
                    result = true;
                }
            }
            return result;
        }
        public List<Battery> GetBatteries()
        {
            List<Battery> result = null;
            if (this.batDB!=null)
            {
                result = this.batDB.GetByLocationId(this.stationId);
            }
            return result;
        }
    }
}
