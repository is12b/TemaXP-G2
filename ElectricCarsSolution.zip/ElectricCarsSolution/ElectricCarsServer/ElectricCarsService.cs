﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ElectricCars.Model;
using ElectricCars.Handlers.ECPathfinder;

namespace ElectricCarsServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class ElectricCarsService : IElectricCarsService
    {
        #region *** Properties ***
        private TimeSpan batteryCharge = new TimeSpan(10, 0, 0);
        private decimal batteryLife = 150;
        private TimeSpan maxBooking = new TimeSpan(24, 0, 0);

        private Path path;
        private Booking booking;
        #endregion

        #region *** Constructors ***
        public ElectricCarsService()
        {
            BookingDB booDB = new BookingDB();
            booDB.RemoveOld(this.maxBooking);
        }
        #endregion

        #region *** Methods ***
        #region *** Test ***
            public string Test(int value)
            {
                return String.Format("This is test contract. Responding to input \"{0}\"",value);
            }
            //public TestModel TestComposite()
            //{
            //    TestModel tm = new TestModel();
            //    tm.MyTestProperty = 5;
            //    return tm;
            //}
            //public List<TestModel> TestList()
            //{
            //    List<TestModel> list = new List<TestModel>(); 
            //    TestModel tm = new TestModel();
            //    tm.MyTestProperty = 5;
            //    list.Add(tm);
            //    return list;
            //}
            public void TestZip()
            {
                Zip item = new Zip();
                item.Code = 9999;
                item.City = "Magic";
                item.Create();
                item.City = "Magic2";
                item.Update();
                item.Delete();
            }
            public void TestLocation()
            {
                Location item = new Location();
                item.Name = "MagicLocation";
                item.Latitude = 5.95m;
                item.Longitude = 12.15m;
                item.Address = "Feiryway 5";

                ZipDB zipDb = new ZipDB();
                item.Zip = zipDb.GetByCode(4200);
                item.Create();

                item.Name = "MagicStation";
                item.Update();
                item.Delete();
            }
            public void TestBattery()
            {
                LocationDB locDB = new LocationDB();
                Battery b = new Battery();
                b.Location = locDB.GetById(1105);
                b.Create();
                b.Id = 52;
                b.Location = locDB.GetById(1066);
                b.Replaced = DateTime.Now;
                b.Update();
                b.Delete();
            }
            public void TestLink()
            {
                LocationDB locDB = new LocationDB();
                Link l = new Link();
                l.Location1 = locDB.GetById(1066);
                l.Location2 = locDB.GetById(1105);
                l.Time = new TimeSpan(10, 0, 0);
                l.Distance = 500;
                l.Create();
                l.Distance = 600;
                l.Update();
                l.Delete();
            }
            public void TestBook()
            {
                Booking b = new Booking();
                b.Create();
                b.Delete();
            }
            public void TestCRUD()
            {
                this.TestZip();
                this.TestLocation();
                this.TestBattery();
                this.TestLink();
                this.TestBook();
            }
            public void TestUser()
            {
                //this.GetLocations();
                this.GetPath(1066,1105);
                this.BookBatteries();
                //this.CancelBooking();
            }
            public void TestManager()
            {
                //this.GetBatteries();
                this.ChangeBattery(4);
                this.ChangeBattery(5);
                this.ChangeBattery(6);
                this.ChangeBattery(25);
                this.ChangeBattery(26);
                this.ChangeBattery(27);
                this.ChangeBattery(43);
                this.ChangeBattery(44);
                this.ChangeBattery(45);
                this.ChangeBattery(46);
                this.ChangeBattery(47);
                this.ChangeBattery(48);

            }
            public void TestAdmin()
            {
                int addedLocId = AddLocation("MagicLand",5.1m,5.3m,"FairyWay 3",2730,"Herlev",2);

                LocationDB locDB = new LocationDB();
                Location toUpdate = locDB.GetById(addedLocId);
                UpdateLocation("NewName", toUpdate.Longitude, toUpdate.Latitude, toUpdate.Address, toUpdate.Zip.Code, toUpdate.Zip.City, addedLocId);
                DeleteLocation(addedLocId);
            }
        #endregion
            #region *** Shared ***
            public List<Location> GetLocations()
            {
                LocationDB lDB = new LocationDB();
                return lDB.GetAll();
            }
        #endregion
        #region *** User ***
            public Path GetPath(int start, int end)
            {
                Pathfinder pf = new Pathfinder();
                this.path = pf.ShortestPath(start, end);
                return path;
            }
            public string BookBatteries()
            {
                string bookingCode = "";
                //if booking doesnt exist create new
                if (this.booking == null)
                {
                    this.booking = new Booking();
                    this.booking.Create();
                }
                // just make sure that book batteries was called after path was found
                if (this.path != null)
                {
                    //book the batteries
                    //List<Battery> batteries = p.Batteries;
                    this.booking.Batteries = path.Batteries;
                    bool success = this.booking.Book().Success;
                    if (success)
                    {
                        // if booking successfull 
                        // 1) nulify path
                        this.path = null;

                        // 2) clear booking
                        bookingCode = this.booking.Id.ToString();
                        this.booking = null;
                    }
                }
                return bookingCode;
            }
            public void CancelBooking()
            {
                if (this.booking !=null) //if booking was created
                {
                    this.booking = null; // nulify booking
                    this.booking.Delete(); // remove from database
                }
            }
        #endregion
        #region *** Manager ***
            public bool ChangeBattery(int id)
            {
                BatteryDB batDB = new BatteryDB();
                Battery b = batDB.GetById(id);
                return b.Release().Success;
            }
            public List<Battery> GetBatteries(int stationId)
            {
                BatteryDB batDB = new BatteryDB();
                return batDB.GetByLocationId(stationId);
            }
        #endregion
        #region *** Admin ***
            public int AddLocation(string name, decimal longitude, decimal latitude, string address, int zip, string city, int batteriesCount)    
            {

                Location l = new Location();
                l.Name = name;
                l.Longitude = longitude;
                l.Latitude = latitude;
                l.Address = address;

                l.Zip = new Zip();
                l.Zip.Code = zip;
                l.Zip.City = city;

                l.Create();

                if (l.Id > 0)
                {
                    BatteryDB batDB = new BatteryDB();
                    batDB.CreateBatch(l.Id, batteriesCount);
                }
                return l.Id;
            }
            public void UpdateLocation(string name, decimal longitude, decimal latitude, string address, int zip, string city, int id)
            {
                Location l = new Location();
                l.Name = name;
                l.Longitude = longitude;
                l.Latitude = latitude;
                l.Address = address;

                l.Zip = new Zip();
                l.Zip.Code = zip;
                l.Zip.City = city;

                l.Update();
            }
            public bool DeleteLocation(int id)
            {
                bool result = false;
                LocationDB locDB = new LocationDB();
                Location loc = locDB.GetById(id);
                loc.Delete();
                loc = locDB.GetById(id);
                if (loc == null)
                {
                    result = true;
                }
                return result;
            }
            public void CreateLink(int loc1, int loc2, decimal km, int hr, int min)
            {
                LocationDB locDB = new LocationDB();
                Link l = new Link();
                l.Location1 = locDB.GetById(loc1);
                l.Location2 = locDB.GetById(loc2);
                l.Time = new TimeSpan(hr, min, 0);
                l.Distance = km;
                l.Create();
            }
            public void UpdateLink(int loc1, int loc2, decimal km, int hr, int min)
            {
                LinkDB linkDB = new LinkDB();
                Link l = linkDB.GetByBoth(loc1, loc2);
                l.Distance = km;
                l.Time = new TimeSpan(hr, min, 0);
                l.Update();
            }
            public void DeleteLink(int loc1, int loc2)
            {
                LinkDB linkDB = new LinkDB();
                Link l = linkDB.GetByBoth(loc1, loc2);
                l.Delete();
            }
        #endregion
        #endregion
    }
}
