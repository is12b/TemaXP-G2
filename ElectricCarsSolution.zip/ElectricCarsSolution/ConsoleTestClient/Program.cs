﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleTestClient.ElectricCarsServerServiceReference;

namespace ConsoleTestClient
{
    class Program
    {
        static IElectricCarsService proxy = new ElectricCarsServiceClient();
        private int start;
        private int end;
        private Booking b;
        private Path path;

        static void Main(string[] args)
        {
            new Program();
        }

        private Program()
        {
            // get locations
            Console.WriteLine("Getting locations. Please wait...");
            List<Location> loc = proxy.GetLocations().ToList();

            foreach (var l in loc)
            {
                Console.WriteLine("ID: "+l.Id+" Coordinates: "+l.DisplayLatitude + " " + l.DisplayLongitude);
            }
            //get path
            Console.WriteLine("Enter departure location ID: ");
            string start = Console.ReadLine();
            Console.WriteLine("Enter arrival location ID: ");
            string end = Console.ReadLine();
            Console.WriteLine("Calculating path...");
            
            // book path
            this.Booking(Convert.ToInt32(start), Convert.ToInt32(end));
            if (this.b!=null)
            {
                Console.WriteLine("Booking is successful. Your booking id is: {0}", b.Id);
            }

            //manager functions
            // release booking
            foreach (Location station in path.Stations)
            {
                this.Release(station.Id);
            }

            // admin functions

            // read locations
            foreach (var l in loc)
            {
                Console.WriteLine("ID: " + l.Id + " Coordinates: " + l.DisplayLatitude + " " + l.DisplayLongitude);
            }
            // add location
            this.AddLocation();

            // update location
            this.UpdateLocation();

            // delete location
            this.DeleteLocation();

            Console.ReadLine();
        }

        private void DeleteLocation()
        {
            
            Console.WriteLine("Location id: ");
            int id = Convert.ToInt32(Console.ReadLine());
            proxy.DeleteLocation(id);
        }

        private void UpdateLocation()
        {
            Console.WriteLine("Updating location");
            Console.WriteLine("Location id: ");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Longitude: ");
            decimal longitude = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Latitude: ");
            decimal latitude = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Address: ");
            string address = Console.ReadLine();
            Console.WriteLine("Zip: ");
            int zip = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("City: ");
            string city = Console.ReadLine();
            proxy.UpdateLocation(name, longitude, latitude, address, zip, city, id);
        }

        private void AddLocation()
        {
            Console.WriteLine("Creating new location");
            Console.WriteLine("Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Longitude: ");
            decimal longitude = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Latitude: ");
            decimal latitude = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Address: ");
            string address = Console.ReadLine();
            Console.WriteLine("Zip: ");
            int zip = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("City: ");
            string city = Console.ReadLine();
            Console.WriteLine("Number of batteries total: ");
            int batteries = Convert.ToInt32(Console.ReadLine());
            proxy.AddLocation(name, longitude, latitude, address, zip, city, batteries);
        }

        private void Release(int locationId)
        {
            List<Battery> batteries = proxy.GetBatteries(locationId).ToList();
            foreach (Battery bat in batteries)
            {
                Console.WriteLine("#{0} - Booking ID: {1} ", bat.Id, bat.Booking !=null?bat.Booking.Id.ToString():"Free");
            }
            Console.WriteLine("Enter battery ID to release: ");
            string batteryId = Console.ReadLine();
            proxy.ChangeBattery(Convert.ToInt32(batteryId));
        }

        private void Booking(int start, int end)
        {
            this.path = proxy.GetPath(start, end);

            List<int> stations = new List<int>();
            foreach (PathNode node in this.path.Route)
            {
                Location l = node.Location;
                string pathNodeInfo = "ID: " + l.Id + " Coordinates: " + l.DisplayLatitude + " " + l.DisplayLongitude;
                if (node.IsStation)
                {
                    pathNodeInfo += " (change battery here)";
                    stations.Add(l.Id);
                }
                Console.WriteLine(pathNodeInfo);
            }
            // book
            Console.WriteLine("Book batteries? Y/N");
            string bookCmd = Console.ReadLine();
            switch (bookCmd)
            {
                case "Y":
                    b = proxy.BookBatteries(true);
                    if (b.Id==Guid.Empty)
                    {
                        Console.WriteLine("Booking failed. Find another path? Y/N");
                        string tryAgain = Console.ReadLine();
                        switch (tryAgain)
                        {
                            case "Y":
                                this.Booking(start, end);
                                break;
                            case "N":
                                proxy.BookBatteries(false);
                                break;
                            default:
                                break;
                        }
                    }
                    break;
                case "N":
                    proxy.BookBatteries(false);
                    break;
                default:
                    break;
            }
        }
    }
}
